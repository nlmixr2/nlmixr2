foceiModel <- list()

foceiModel[["inner"]] <- NULL

foceiModel[["innerOeta"]] <- NULL

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4]);\ncmt(depot);\ncmt(center);\nrx_expr_0~exp(THETA[1]);\nd/dt(depot)=-rx_expr_0*depot;\nd/dt(center)=rx_expr_0*depot-exp(THETA[2]-THETA[3])*center;\nrx_yj_~162;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_1~exp(-THETA[3]);\nrx_expr_2~rx_expr_1*center;\nrx_pred_=rx_expr_2;\nrx_r_=Rx_pow_di(THETA[4],2);\ntka=THETA[1];\ntcl=THETA[2];\ntv=THETA[3];\nadd.sd=THETA[4];\nka=rx_expr_0;\ncl=exp(THETA[2]);\nv=exp(THETA[3]);\ncp=rx_expr_2;\ntad=tad();\ndosenum=dosenum();\ncmt(cp);\ndvid(3);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- NULL

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- integer(0)

foceiModel[["predOnlyLlik"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4]);\ncmt(depot);\ncmt(center);\nrx_expr_0~exp(THETA[1]);\nd/dt(depot)=-rx_expr_0*depot;\nd/dt(center)=rx_expr_0*depot-exp(THETA[2]-THETA[3])*center;\nrx_yj_~162;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_1~exp(-THETA[3]);\nrx_expr_2~rx_expr_1*center;\nrx_pred_=llikNorm(DV,rx_expr_2,sqrt(Rx_pow_di(THETA[4],2)));\nrx_r_=0;\ntka=THETA[1];\ntcl=THETA[2];\ntv=THETA[3];\nadd.sd=THETA[4];\nka=rx_expr_0;\ncl=exp(THETA[2]);\nv=exp(THETA[3]);\ncp=rx_expr_2;\ntad=tad();\ndosenum=dosenum();\ncmt(cp);\ndvid(3);\n")

class(foceiModel) <- "foceiModelList"

