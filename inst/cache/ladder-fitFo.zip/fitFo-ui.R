ui <- function () 
{
    ini({
        tka <- 1.06500285836566
        tcl <- 1.01941325440658
        tv <- 3.50457262257316
        add.sd <- c(0, 0.614390439376624)
        eta.ka ~ 0.841369592736821
        eta.cl ~ 0.0909197354567924
        eta.v ~ 0.0191032993042017
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

