ui <- function () 
{
    ini({
        tka <- 0.613936538865719
        tcl <- 0.963440967467104
        tv <- 3.52370317229836
        add.sd <- c(0, 1.42653987206264)
    })
    model({
        ka <- exp(tka)
        cl <- exp(tcl)
        v <- exp(tv)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "popModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

