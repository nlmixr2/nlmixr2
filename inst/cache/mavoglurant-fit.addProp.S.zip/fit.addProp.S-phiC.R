phiC <- list(lotri({
    eta.LClint ~ 0.0192054042800735
}), lotri({
    eta.LClint ~ 0.0180248169429098
}), lotri({
    eta.LClint ~ 0.0190375322811644
}), lotri({
    eta.LClint ~ 0.0269990919990219
}), lotri({
    eta.LClint ~ 0.0145491342933789
}), lotri({
    eta.LClint ~ 0.0157218982135335
}), lotri({
    eta.LClint ~ 0.0168824692876825
}), lotri({
    eta.LClint ~ 0.0201127548373182
}), lotri({
    eta.LClint ~ 0.0155058450683868
}), lotri({
    eta.LClint ~ 0.0216911697627186
}), lotri({
    eta.LClint ~ 0.0181171147442764
}), lotri({
    eta.LClint ~ 0.0220950142242155
}), lotri({
    eta.LClint ~ 0.0239203858811674
}), lotri({
    eta.LClint ~ 0.0235125695279408
}), lotri({
    eta.LClint ~ 0.0166190501950173
}), lotri({
    eta.LClint ~ 0.0201551938653007
}), lotri({
    eta.LClint ~ 0.0205715983038454
}), lotri({
    eta.LClint ~ 0.0180335096643295
}), lotri({
    eta.LClint ~ 0.020737773305763
}))
names(phiC) <- c("793", "794", "795", "796", "797", "798", "799", "800", "801", "802", "803", "804", "805", "806", "807", "808", "809", "810", "811")
