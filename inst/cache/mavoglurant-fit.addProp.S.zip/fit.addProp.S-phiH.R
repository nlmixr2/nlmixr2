phiH <- list(lotri({
    eta.LClint ~ 52.0686774106363
}), lotri({
    eta.LClint ~ 55.4790655110291
}), lotri({
    eta.LClint ~ 52.5278163803506
}), lotri({
    eta.LClint ~ 37.0382826221055
}), lotri({
    eta.LClint ~ 68.7326118403546
}), lotri({
    eta.LClint ~ 63.6055510866488
}), lotri({
    eta.LClint ~ 59.2330412666351
}), lotri({
    eta.LClint ~ 49.7196932040632
}), lotri({
    eta.LClint ~ 64.4918090945452
}), lotri({
    eta.LClint ~ 46.1017091719385
}), lotri({
    eta.LClint ~ 55.1964269208994
}), lotri({
    eta.LClint ~ 45.2590792588868
}), lotri({
    eta.LClint ~ 41.8053456565391
}), lotri({
    eta.LClint ~ 42.5304430811642
}), lotri({
    eta.LClint ~ 60.1719104440648
}), lotri({
    eta.LClint ~ 49.6150027969519
}), lotri({
    eta.LClint ~ 48.6107100299091
}), lotri({
    eta.LClint ~ 55.4523228486139
}), lotri({
    eta.LClint ~ 48.2211848521895
}))
names(phiH) <- c("793", "794", "795", "796", "797", "798", "799", "800", "801", "802", "803", "804", "805", "806", "807", "808", "809", "810", "811")
