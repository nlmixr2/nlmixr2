ui <- function () 
{
    ini({
        tka <- 0.463237513713545
        tcl <- 1.01191658795102
        tv <- 3.4598324058907
        add.sd <- c(0, 0.694355316610102)
        eta.ka ~ 0.400487488767866
        eta.cl ~ 0.0686932830714198
        eta.v ~ 0.0193600847723376
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

