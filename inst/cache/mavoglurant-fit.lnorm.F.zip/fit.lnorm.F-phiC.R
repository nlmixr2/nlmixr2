phiC <- list(lotri({
    eta.LClint ~ 0.0089418431596927
}), lotri({
    eta.LClint ~ 0.0144443594566953
}), lotri({
    eta.LClint ~ 0.0143948223333503
}), lotri({
    eta.LClint ~ 0.0089147617271786
}), lotri({
    eta.LClint ~ 0.0108950390491258
}), lotri({
    eta.LClint ~ 0.0143546543981399
}), lotri({
    eta.LClint ~ 0.0113040691103106
}), lotri({
    eta.LClint ~ 0.0188292696728948
}), lotri({
    eta.LClint ~ 0.0141155724406755
}), lotri({
    eta.LClint ~ 0.0149243367039349
}), lotri({
    eta.LClint ~ 0.0112421340320186
}), lotri({
    eta.LClint ~ 0.0156484549680093
}), lotri({
    eta.LClint ~ 0.0168621854790822
}), lotri({
    eta.LClint ~ 0.0123795305668395
}), lotri({
    eta.LClint ~ 0.0152319678620503
}), lotri({
    eta.LClint ~ 0.012476155787642
}), lotri({
    eta.LClint ~ 0.00947437612336607
}), lotri({
    eta.LClint ~ 0.0157046919939128
}), lotri({
    eta.LClint ~ 0.0124608249293411
}))
names(phiC) <- c("793", "794", "795", "796", "797", "798", "799", "800", "801", "802", "803", "804", "805", "806", "807", "808", "809", "810", "811")
