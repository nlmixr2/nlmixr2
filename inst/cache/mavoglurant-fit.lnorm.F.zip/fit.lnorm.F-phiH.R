phiH <- list(lotri({
    eta.LClint ~ 111.833766499922
}), lotri({
    eta.LClint ~ 69.2311765708983
}), lotri({
    eta.LClint ~ 69.4694228829191
}), lotri({
    eta.LClint ~ 112.17349724012
}), lotri({
    eta.LClint ~ 91.7848936099259
}), lotri({
    eta.LClint ~ 69.6638158094271
}), lotri({
    eta.LClint ~ 88.4637195899563
}), lotri({
    eta.LClint ~ 53.1088043972053
}), lotri({
    eta.LClint ~ 70.8437439716149
}), lotri({
    eta.LClint ~ 67.0046528591348
}), lotri({
    eta.LClint ~ 88.9510832331221
}), lotri({
    eta.LClint ~ 63.9040724496018
}), lotri({
    eta.LClint ~ 59.3042936955304
}), lotri({
    eta.LClint ~ 80.7785072786729
}), lotri({
    eta.LClint ~ 65.6513990218855
}), lotri({
    eta.LClint ~ 80.1528946112175
}), lotri({
    eta.LClint ~ 105.547846842787
}), lotri({
    eta.LClint ~ 63.6752379726777
}), lotri({
    eta.LClint ~ 80.2515086818475
}))
names(phiH) <- c("793", "794", "795", "796", "797", "798", "799", "800", "801", "802", "803", "804", "805", "806", "807", "808", "809", "810", "811")
