ui <- function () 
{
    ini({
        lW0 <- 8.18293049253
        lkin <- 4.49865811027
        lTL <- 0.512124479978
        lkoutmax <- -2.65485262837
        lT50 <- 0.020230587301
        add.err <- c(0, 17.9714755277)
        prop.err <- c(0, 0.00992620770633)
        beta_lW0_SEX <- 0.0899327583251
        beta_lW0_GA <- 1.85802166713
        beta_lkin_GA <- 1.88030001206
        eta.W0 ~ 0.0159450547485
        eta.kin ~ 0.0367479615613
        eta.TL ~ 0.0170515722265
        eta.koutmax ~ 0.00994443162136
        eta.T50 ~ 0.0238772782812
    })
    model({
        W0 <- exp(lW0 + beta_lW0_SEX * (SEX - 0.481481481481) + 
            beta_lW0_GA * log(GA/39.7114451852) + eta.W0)
        kin <- exp(lkin + beta_lkin_GA * log(GA/39.7114451852) + 
            eta.kin)
        TL <- exp(lTL + eta.TL)
        koutmax <- exp(lkoutmax + eta.koutmax)
        T50 <- exp(lT50 + eta.T50)
        kprod <- kin * expit(2 * (t - TL), 0, 1)
        kelim <- koutmax * (1 - t/(T50 + t))
        d/dt(W) <- kprod - kelim * W
        W(0) <- W0
        W ~ add(add.err) + prop(prop.err)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "x", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

