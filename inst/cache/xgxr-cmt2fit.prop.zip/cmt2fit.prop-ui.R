ui <- function () 
{
    ini({
        lka <- 11.7029142011283
        label("Ka")
        lv <- 5.17179981976733
        label("Vc")
        lcl <- 170.184017919805
        label("Cl")
        lq <- -0.155916446964414
        label("Q")
        lvp <- 5.74382960163138
        label("Vp")
        prop.sd <- c(0, 1.36170791965875e+148)
        eta.ka ~ 0.650707723821154
        eta.v ~ 0.107085428460062
        eta.cl ~ 0.0834318592151006
    })
    model({
        ka <- exp(lka + eta.ka)
        cl <- exp(lcl + eta.cl)
        v <- exp(lv + eta.v)
        q <- exp(lq)
        vp <- exp(lvp)
        linCmt() ~ prop(prop.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", c("$", "rxui", "fun"), envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

