saemModel <- list()

saemModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],ETA[3]);\nrx_pred_=NA;\nrx_r_=NA;\nlka=THETA[1]+ETA[1];\nlv=THETA[2]+ETA[2];\nlcl=THETA[3]+ETA[3];\nlq=THETA[4];\nlvp=THETA[5];\nprop.sd=THETA[6];\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=linCmtA(rx__PTR__,t,2,2,1,-1,1,exp(lcl),exp(lv),exp(lq),exp(lvp),0,0,exp(lka));\nrx_expr__0~exp(lv);\nrx_expr__1~exp(lq);\nrx_expr__2~exp(lcl);\nrx_expr__3~exp(lvp);\nrx_expr__4~exp(lka);\nrx_r_=Rx_pow_di((linCmtA(rx__PTR__,t,2,2,1,-1,1,rx_expr__2,rx_expr__0,rx_expr__1,rx_expr__3,0,0,rx_expr__4)*prop.sd),2);\nka=rx_expr__4;\ncl=rx_expr__2;\nv=rx_expr__0;\nq=rx_expr__1;\nvp=rx_expr__3;\ntad=tad();\ndosenum=dosenum();\nlka=THETA[1];\nlv=THETA[2];\nlcl=THETA[3];\nlq=THETA[4];\nlvp=THETA[5];\nprop.sd=THETA[6];\neta.ka=ETA[1];\neta.v=ETA[2];\neta.cl=ETA[3];\ncmt(rxLinCmt);\ndvid(3);\n")

class(saemModel) <- "saemModelList"

