ui <- function () 
{
    ini({
        tka <- 0.415925052922516
        label("Ka")
        tcl <- 1.02465299712209
        label("Cl")
        tv <- 3.46819298493296
        label("V")
        add.err <- c(0, 0.281802533358863)
        prop.err <- c(0, 0.131205745898734)
        eta.ka ~ 0.399809367158948
        eta.cl ~ 0.0644576835967773
        eta.v ~ 0.0178968201968518
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) = -ka * depot
        d/dt(center) = ka * depot - cl/v * center
        cp = center/v
        cp ~ add(add.err) + prop(prop.err)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", c("$", "rxui", "fun"), envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

