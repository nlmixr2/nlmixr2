ui <- function () 
{
    ini({
        tka <- 0.321431671661034
        tcl1 <- -3.50268840525198
        tcl2 <- -5.83232833972083
        tv <- 3.46929795347318
        p1 <- 0.666666666135653
        add.sd <- c(0, 0.414140672443564)
        eta.cl ~ 1.20604938541245
        eta.v ~ 0.0359367160981113
    })
    model({
        ka <- exp(tka)
        cl <- mix(expit(tcl1 + eta.cl, 0.1, 200), p1, expit(tcl2 + 
            eta.cl, 0.1, 200))
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", ".funNew", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

