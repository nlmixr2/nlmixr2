ui <- function () 
{
    ini({
        tk4 <- -2.30881869821655
        tk5 <- -2.10035830074853
        tT <- 2.56851005458405
        tb <- -0.897251912132321
        prop.pk <- c(0, 0.525814088407469)
        add.tas <- c(0, 1.90359717945348)
        add.aks <- c(0, 1.0442290135718)
        eta.T ~ 0.00659915197310703
    })
    model({
        k <- 0.184
        V <- 0.039
        k1 <- 0.535
        k2 <- 0.352
        k3 <- 5
        k4 <- exp(tk4)
        k5 <- exp(tk5)
        Emax <- 1
        EC50 <- 44.3
        T <- exp(tT + eta.T)
        I0 <- 2.42
        a <- 1
        b <- exp(tb)
        d/dt(Ac) <- -k * Ac
        c <- Ac/V
        eff <- (Emax * c)/(EC50 + c)
        G(0) <- a
        d/dt(G) <- k3 - eff * G - (k1/k2) * (1 - exp(-k2 * t)) * 
            G
        past(G, T) <- a * exp(b * t)
        I(0) <- I0
        d/dt(I) <- k4 * G - k4 * delay(G, T)
        D(0) <- 0
        d/dt(D) <- k4 * delay(G, T) - k5 * D
        TAS <- I + D
        AKS <- D
        c ~ prop(prop.pk)
        TAS ~ add(add.tas)
        AKS ~ add(add.aks)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "mod6", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

