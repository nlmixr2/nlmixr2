foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],ETA[3]);\nrx_yj_~3;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~exp(THETA[4]);\nrx_expr_1~exp(THETA[5]);\nrx_expr_2~ETA[3]+THETA[3];\nrx_expr_3~ETA[2]+THETA[2];\nrx_expr_4~ETA[1]+THETA[1];\nrx_expr_5~exp(rx_expr_2);\nrx_expr_6~exp(rx_expr_3);\nrx_expr_7~exp(rx_expr_4);\nrx_pred_=log(linCmtB(rx__PTR__,t,2,2,1,-1,-1,1,rx_expr_5,rx_expr_6,rx_expr_0,rx_expr_1,0,0,rx_expr_7));\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_7*linCmtB(rx__PTR__,t,2,2,1,-2,4,1,rx_expr_5,rx_expr_6,rx_expr_0,rx_expr_1,0,0,rx_expr_7)/linCmtB(rx__PTR__,t,2,2,1,-1,-1,1,rx_expr_5,rx_expr_6,rx_expr_0,rx_expr_1,0,0,rx_expr_7);\nrx__sens_rx_pred__BY_ETA_2___=rx_expr_6*linCmtB(rx__PTR__,t,2,2,1,-2,1,1,rx_expr_5,rx_expr_6,rx_expr_0,rx_expr_1,0,0,rx_expr_7)/linCmtB(rx__PTR__,t,2,2,1,-1,-1,1,rx_expr_5,rx_expr_6,rx_expr_0,rx_expr_1,0,0,rx_expr_7);\nrx__sens_rx_pred__BY_ETA_3___=rx_expr_5*linCmtB(rx__PTR__,t,2,2,1,-2,0,1,rx_expr_5,rx_expr_6,rx_expr_0,rx_expr_1,0,0,rx_expr_7)/linCmtB(rx__PTR__,t,2,2,1,-1,-1,1,rx_expr_5,rx_expr_6,rx_expr_0,rx_expr_1,0,0,rx_expr_7);\nrx_r_=Rx_pow_di(THETA[6],2);\nrx__sens_rx_r__BY_ETA_1___=0;\nrx__sens_rx_r__BY_ETA_2___=0;\nrx__sens_rx_r__BY_ETA_3___=0;\ncmt(rxLinCmt);\ndvid(3);\n")

foceiModel[["innerOeta"]] <- "rx_yj_~3\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_expr_0~exp(THETA[4])\nrx_expr_1~exp(THETA[5])\nrx_expr_2~ETA[3]+THETA[3]\nrx_expr_3~ETA[2]+THETA[2]\nrx_expr_4~ETA[1]+THETA[1]\nrx_expr_5~exp(rx_expr_2)\nrx_expr_6~exp(rx_expr_3)\nrx_expr_7~exp(rx_expr_4)\nrx_pred_=log(linCmtB(rx__PTR__, t, 2, 2, 1, -1, -1, 1, rx_expr_5, rx_expr_6, rx_expr_0, rx_expr_1, 0, 0, rx_expr_7))\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_7*linCmtB(rx__PTR__, t, 2, 2, 1, -2, 4, 1, rx_expr_5, rx_expr_6, rx_expr_0, rx_expr_1, 0, 0, rx_expr_7)/linCmtB(rx__PTR__, t, 2, 2, 1, -1, -1, 1, rx_expr_5, rx_expr_6, rx_expr_0, rx_expr_1, 0, 0, rx_expr_7)\nrx__sens_rx_pred__BY_ETA_2___=rx_expr_6*linCmtB(rx__PTR__, t, 2, 2, 1, -2, 1, 1, rx_expr_5, rx_expr_6, rx_expr_0, rx_expr_1, 0, 0, rx_expr_7)/linCmtB(rx__PTR__, t, 2, 2, 1, -1, -1, 1, rx_expr_5, rx_expr_6, rx_expr_0, rx_expr_1, 0, 0, rx_expr_7)\nrx__sens_rx_pred__BY_ETA_3___=rx_expr_5*linCmtB(rx__PTR__, t, 2, 2, 1, -2, 0, 1, rx_expr_5, rx_expr_6, rx_expr_0, rx_expr_1, 0, 0, rx_expr_7)/linCmtB(rx__PTR__, t, 2, 2, 1, -1, -1, 1, rx_expr_5, rx_expr_6, rx_expr_0, rx_expr_1, 0, 0, rx_expr_7)\nrx_r_=Rx_pow_di(THETA[6], 2)\nrx__sens_rx_r__BY_ETA_1___=0\nrx__sens_rx_r__BY_ETA_2___=0\nrx__sens_rx_r__BY_ETA_3___=0\nrx__ETA1=ETA[1]\nrx__ETA2=ETA[2]\nrx__ETA3=ETA[3]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],ETA[3]);\nrx_yj_~3;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~exp(THETA[4]);\nrx_expr_1~exp(THETA[5]);\nrx_expr_2~ETA[3]+THETA[3];\nrx_expr_3~ETA[2]+THETA[2];\nrx_expr_4~ETA[1]+THETA[1];\nrx_expr_5~exp(rx_expr_2);\nrx_expr_6~exp(rx_expr_3);\nrx_expr_7~exp(rx_expr_4);\nrx_pred_=log(linCmtB(rx__PTR__,t,2,2,1,-1,-1,1,rx_expr_5,rx_expr_6,rx_expr_0,rx_expr_1,0,0,rx_expr_7));\nrx_r_=Rx_pow_di(THETA[6],2);\nlka=THETA[1];\nlv=THETA[2];\nlcl=THETA[3];\nlq=THETA[4];\nlvp=THETA[5];\nlogn.sd=THETA[6];\neta.ka=ETA[1];\neta.v=ETA[2];\neta.cl=ETA[3];\nka=rx_expr_7;\ncl=rx_expr_5;\nv=rx_expr_6;\nq=rx_expr_0;\nvp=rx_expr_1;\ntad=tad();\ndosenum=dosenum();\ncmt(rxLinCmt);\ndvid(3);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],ETA[3]);\nparam(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],ETA[3]);\nrx_yj_~3;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=log(linCmtB(rx__PTR__,t,2,2,1,-1,-1,1,exp(ETA[3]+THETA[3]),exp(ETA[2]+THETA[2]),exp(THETA[4]),exp(THETA[5]),0,0,exp(ETA[1]+THETA[1])));\nrx_r_=Rx_pow_di(THETA[6],2);\ncmt(rxLinCmt);\ndvid(3);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- c(0L, 0L, 0L)

class(foceiModel) <- "foceiModelList"

