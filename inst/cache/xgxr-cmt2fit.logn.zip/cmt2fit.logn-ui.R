ui <- function () 
{
    ini({
        lka <- -0.187441583313502
        label("Ka")
        lv <- 3.45650572219176
        label("Vc")
        lcl <- 2.59861242510258
        label("Cl")
        lq <- 3.41379136574118
        label("Q")
        lvp <- 5.33113692180379
        label("Vp")
        logn.sd <- c(0, 1.11690438201096)
        eta.ka ~ 0.00905255327919764
        eta.v ~ 0.0120144137075567
        eta.cl ~ 0.193866143215247
    })
    model({
        ka <- exp(lka + eta.ka)
        cl <- exp(lcl + eta.cl)
        v <- exp(lv + eta.v)
        q <- exp(lq)
        vp <- exp(lvp)
        linCmt() ~ lnorm(logn.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "cmt2", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

