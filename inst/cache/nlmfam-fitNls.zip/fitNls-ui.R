ui <- function () 
{
    ini({
        tka <- 0.440298211615317
        tcl <- 0.96148907514657
        tv <- 3.49229024183171
        add.sd <- c(0, 1.38063399815546)
    })
    model({
        ka <- exp(tka)
        cl <- exp(tcl)
        v <- exp(tv)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "popModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

