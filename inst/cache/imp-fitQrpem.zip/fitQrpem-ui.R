ui <- function () 
{
    ini({
        tka <- 0.458026479690233
        tcl <- 1.01221985310738
        tv <- 3.45357680874893
        add.sd <- c(0, 0.697806739972602)
        eta.ka ~ 0.406735939594372
        eta.cl ~ 0.0698264624849959
        eta.v ~ 0.0184199721017756
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "impModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

