ui <- function () 
{
    ini({
        tka <- 0.339824253833874
        label("Log Ka")
        tcl <- 0.927006629187964
        label("Log Cl")
        tv <- 3.52218309807813
        label("Log V")
        add.sd <- c(0, 0.516006266946502)
        label("Pooled additive error (mg/L)")
        eta.ka ~ 0.41453094796981
        eta.cl ~ 0.340595843333449
        eta.v ~ 0.119257609517077
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "pkPooled", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

