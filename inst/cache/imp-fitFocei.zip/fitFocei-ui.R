ui <- function () 
{
    ini({
        tka <- 0.464546810072026
        tcl <- 1.01172893884323
        tv <- 3.45975585515283
        add.sd <- c(0, 0.694648189277606)
        eta.ka ~ 0.401021246896965
        eta.cl ~ 0.0698445796659257
        eta.v ~ 0.0191933560471847
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "impModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

