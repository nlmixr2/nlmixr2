ui <- function () 
{
    ini({
        tka <- 0.463365090369258
        tcl <- 1.01167091986626
        tv <- 3.45980345281505
        add.sd <- c(0, 0.694503134778055)
        eta.ka ~ 0.402499386154909
        eta.cl ~ 0.069546795772001
        eta.v ~ 0.0192053159544873
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

