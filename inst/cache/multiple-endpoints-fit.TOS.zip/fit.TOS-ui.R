ui <- function () 
{
    ini({
        tktr <- 0.150892191148098
        tka <- -0.072408495686017
        tcl <- -1.96580813938945
        tv <- 2.00206920619015
        prop.err <- c(0, 0.126333262780434)
        pkadd.err <- c(0, 0.783500083981139)
        temax <- 2.74753106868851
        tec50 <- -0.240885981316099
        tkout <- -2.88887385969022
        te0 <- 4.57094138036238
        pdadd.err <- c(0, 3.83694304864317)
        eta.ktr ~ 0.393226103749419
        eta.ka ~ 0.225532201428989
        eta.cl ~ 0.0696963953705758
        eta.v ~ 0.0417021638263417
        eta.emax ~ 0.00579324777316081
        eta.ec50 ~ 0.227536564809807
        eta.kout ~ 0.00254234652259555
        eta.e0 ~ 0.00239264892389457
    })
    model({
        ktr <- exp(tktr + eta.ktr)
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        emax = expit(temax + eta.emax, 0, 1)
        ec50 = exp(tec50 + eta.ec50)
        kout = exp(tkout + eta.kout)
        e0 = exp(te0 + eta.e0)
        DCP = center/v
        PD = 1 - emax * DCP/(ec50 + DCP)
        effect(0) = e0
        kin = e0 * kout
        d/dt(depot) = -ktr * depot
        d/dt(gut) = ktr * depot - ka * gut
        d/dt(center) = ka * gut - cl/v * center
        d/dt(effect) = kin * PD - kout * effect
        cp = center/v
        cp ~ prop(prop.err) + add(pkadd.err)
        effect ~ add(pdadd.err) | pca
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "pk.turnover.emax3", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

