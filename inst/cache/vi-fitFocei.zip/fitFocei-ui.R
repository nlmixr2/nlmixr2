ui <- function () 
{
    ini({
        tka <- 0.405237735613491
        tcl <- 1.03049163236473
        tv <- 3.42926248502324
        add.sd <- c(0, 0.780828960563685)
        eta.ka ~ 0.326161660188747
        eta.cl ~ 0.121336965900497
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

