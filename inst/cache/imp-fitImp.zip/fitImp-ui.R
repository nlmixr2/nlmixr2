ui <- function () 
{
    ini({
        tka <- 0.461462600149134
        tcl <- 1.00776992179522
        tv <- 3.4537476535381
        add.sd <- c(0, 0.697485249668009)
        eta.ka ~ 0.406616282857397
        eta.cl ~ 0.0703791590623396
        eta.v ~ 0.0186347672694718
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "impModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

