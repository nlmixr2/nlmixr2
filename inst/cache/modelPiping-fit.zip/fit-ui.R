ui <- function () 
{
    ini({
        tka <- 0.466256075749994
        label("Ka")
        tcl <- 1.01202280348529
        label("Cl")
        tv <- 3.45966515663651
        label("V")
        add.sd <- c(0, 0.694652074674021)
        eta.ka ~ 0.398790718683926
        eta.cl ~ 0.0693628686373601
        eta.v ~ 0.0190767282230426
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) = -ka * depot
        d/dt(center) = ka * depot - cl/v * center
        cp = center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "one.compartment", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

