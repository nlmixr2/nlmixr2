ui <- function () 
{
    ini({
        tka <- fix(0.5)
        label("Ka")
        tcl <- 1.01178094742184
        label("Cl")
        tv <- 3.4607404311407
        label("V")
        add.sd <- c(0, 0.694786643610701)
        eta.ka ~ 0.399636042872118
        eta.cl ~ 0.0693572912943077
        eta.v ~ 0.0190774134098967
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) = -ka * depot
        d/dt(center) = ka * depot - cl/v * center
        cp = center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "one.compartment", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

