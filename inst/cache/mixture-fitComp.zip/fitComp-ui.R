ui <- function () 
{
    ini({
        tka <- 0.169278218870835
        tcl1 <- -3.32247696985298
        tcl2 <- -5.69225452593738
        tv <- 3.38238701371558
        p1 <- 0.647937380075088
        add.sd <- c(0, 0.327109583572646)
        eta.cl ~ 0.126006478046722
        eta.v ~ 0.0335790371369919
    })
    model({
        ka <- exp(tka)
        cl <- mix(expit(tcl1 + eta.cl, 0.1, 200), p1, expit(tcl2 + 
            eta.cl, 0.1, 200))
        v <- exp(tv + eta.v)
        component <- mixest
        nComponents <- mixnum
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "twoPopComp", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

