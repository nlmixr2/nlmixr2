foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2]);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~mixest==1;\nrx_expr_1~mixest==2;\nrx_expr_2~ETA[1]+THETA[2];\nrx_expr_3~ETA[1]+THETA[3];\nrx_expr_4~ETA[2]+THETA[4];\nrx_expr_5~exp(rx_expr_4);\nrx_expr_6~exp(-(rx_expr_2));\nrx_expr_7~exp(-(rx_expr_3));\nrx_expr_8~1+rx_expr_6;\nrx_expr_9~1+rx_expr_7;\nrx_pred_=linCmtB(rx__PTR__,t,2,1,1,-1,-1,1,(rx_expr_0)*(0.1+199.9*(1/(rx_expr_8)))+(rx_expr_1)*(0.1+199.9*(1/(rx_expr_9))),rx_expr_5,0,0,0,0,exp(THETA[1]));\nrx__sens_rx_pred__BY_ETA_1___=((rx__sens_central_BY_p1)/(rx_expr_5))*(199.9*rx_expr_6*(rx_expr_0)/Rx_pow_di((rx_expr_8),2)+199.9*rx_expr_7*(rx_expr_1)/Rx_pow_di((rx_expr_9),2));\nrx__sens_rx_pred__BY_ETA_2___=rx_expr_5*(-(central)/((rx_expr_5)*(rx_expr_5))+(rx__sens_central_BY_v1)/(rx_expr_5));\nrx_r_=Rx_pow_di(THETA[6],2);\nrx__sens_rx_r__BY_ETA_1___=0;\nrx__sens_rx_r__BY_ETA_2___=0;\ncmt(rxLinCmt);\ndvid(3);\n")

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- "rx_yj_~2\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_expr_0~mixest==1\nrx_expr_1~mixest==2\nrx_expr_2~ETA[1]+THETA[2]\nrx_expr_3~ETA[1]+THETA[3]\nrx_expr_4~ETA[2]+THETA[4]\nrx_expr_5~exp(rx_expr_4)\nrx_expr_6~exp(-(rx_expr_2))\nrx_expr_7~exp(-(rx_expr_3))\nrx_expr_8~1+rx_expr_6\nrx_expr_9~1+rx_expr_7\nrx_pred_=linCmtB(rx__PTR__, t, 2, 1, 1, -1, -1, 1, (rx_expr_0)*(0.1+199.9*(1/(rx_expr_8)))+(rx_expr_1)*(0.1+199.9*(1/(rx_expr_9))), rx_expr_5, 0, 0, 0, 0, exp(THETA[1]))\nrx__sens_rx_pred__BY_ETA_1___=((rx__sens_central_BY_p1)/(rx_expr_5))*(199.9*rx_expr_6*(rx_expr_0)/Rx_pow_di((rx_expr_8), 2)+199.9*rx_expr_7*(rx_expr_1)/Rx_pow_di((rx_expr_9), 2))\nrx__sens_rx_pred__BY_ETA_2___=rx_expr_5*(-(central)/((rx_expr_5)*(rx_expr_5))+(rx__sens_central_BY_v1)/(rx_expr_5))\nrx_r_=Rx_pow_di(THETA[6], 2)\nrx__sens_rx_r__BY_ETA_1___=0\nrx__sens_rx_r__BY_ETA_2___=0\nrx__ETA1=ETA[1]\nrx__ETA2=ETA[2]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2]);\ntka=THETA[1];\ntcl1=THETA[2];\ntcl2=THETA[3];\ntv=THETA[4];\np1=THETA[5];\nadd.sd=THETA[6];\neta.cl=ETA[1];\neta.v=ETA[2];\nka=exp(tka);\ncl=mix(expit(tcl1+eta.cl,0.1,200),p1,expit(tcl2+eta.cl,0.1,200));\nv=exp(tv+eta.v);\ncomponent=mixest;\nnComponents=mixnum;\nrx_yj_~2;\nrx_lambda_~1;\nrx_low_~0;\nrx_hi_~1;\nrx_pred_f_~linCmtA(rx__PTR__,t,2,1,1,-1,1,cl,v,0.0,0.0,0.0,0.0,ka);\nrx_pred_~rx_pred_f_;\nrx_r_~(add.sd)^2;\ntad=tad();\ndosenum=dosenum();\ncmt(rxLinCmt);\ndvid(3);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2]);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=linCmtB(rx__PTR__,t,2,1,1,-1,-1,1,(mixest==1)*(0.1+199.9*(1/(1+exp(-(ETA[1]+THETA[2])))))+(mixest==2)*(0.1+199.9*(1/(1+exp(-(ETA[1]+THETA[3]))))),exp(ETA[2]+THETA[4]),0,0,0,0,exp(THETA[1]));\nrx_r_=Rx_pow_di(THETA[6],2);\ncmt(rxLinCmt);\ndvid(3);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- c(0L, 0L)

class(foceiModel) <- "foceiModelList"

