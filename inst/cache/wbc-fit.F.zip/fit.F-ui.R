ui <- function () 
{
    ini({
        log_CIRC0 <- 1.18108201122823
        log_MTT <- 5.05789686198507
        log_SLOPU <- 3.49699833493602
        log_GAMMA <- -1.75713145427186
        prop.err <- c(0, 7.99297767577928)
        eta.CIRC0 ~ 0.123973596877172
        eta.MTT ~ 0.0298599503132495
        eta.SLOPU ~ 0.202669078046438
    })
    model({
        CIRC0 = exp(log_CIRC0 + eta.CIRC0)
        MTT = exp(log_MTT + eta.MTT)
        SLOPU = exp(log_SLOPU + eta.SLOPU)
        GAMMA = exp(log_GAMMA)
        CL = CLI
        V1 = V1I
        V2 = V2I
        Q = 204
        CONC = centr/V1
        NN = 3
        KTR = (NN + 1)/MTT
        EDRUG = 1 - SLOPU * CONC
        FDBK = (CIRC0/circ)^GAMMA
        CIRC = circ
        prol(0) = CIRC0
        tr1(0) = CIRC0
        tr2(0) = CIRC0
        tr3(0) = CIRC0
        circ(0) = CIRC0
        d/dt(centr) = periph * Q/V2 - centr * (CL/V1 + Q/V1)
        d/dt(periph) = centr * Q/V1 - periph * Q/V2
        d/dt(prol) = KTR * prol * EDRUG * FDBK - KTR * prol
        d/dt(tr1) = KTR * prol - KTR * tr1
        d/dt(tr2) = KTR * tr1 - KTR * tr2
        d/dt(tr3) = KTR * tr2 - KTR * tr3
        d/dt(circ) = KTR * tr3 - KTR * circ
        CIRC ~ prop(prop.err)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "wbc", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

