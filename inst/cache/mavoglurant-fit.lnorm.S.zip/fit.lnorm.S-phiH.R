phiH <- list(lotri({
    eta.LClint ~ 122.189342279641
}), lotri({
    eta.LClint ~ 74.467717873157
}), lotri({
    eta.LClint ~ 74.6146558058283
}), lotri({
    eta.LClint ~ 122.488279867208
}), lotri({
    eta.LClint ~ 99.5595845786147
}), lotri({
    eta.LClint ~ 74.9326782302541
}), lotri({
    eta.LClint ~ 95.8482761402264
}), lotri({
    eta.LClint ~ 56.1840525256694
}), lotri({
    eta.LClint ~ 76.2124692052196
}), lotri({
    eta.LClint ~ 71.9209510083436
}), lotri({
    eta.LClint ~ 96.3444198203153
}), lotri({
    eta.LClint ~ 68.2696609923957
}), lotri({
    eta.LClint ~ 62.8537499467465
}), lotri({
    eta.LClint ~ 80.747864885819
}), lotri({
    eta.LClint ~ 70.1506940025013
}), lotri({
    eta.LClint ~ 86.2306298341018
}), lotri({
    eta.LClint ~ 114.731092905495
}), lotri({
    eta.LClint ~ 68.0341676317422
}), lotri({
    eta.LClint ~ 86.2195915665613
}))
names(phiH) <- c("793", "794", "795", "796", "797", "798", "799", "800", "801", "802", "803", "804", "805", "806", "807", "808", "809", "810", "811")
