phiC <- list(lotri({
    eta.LClint ~ 0.0081840198281075
}), lotri({
    eta.LClint ~ 0.0134286376507916
}), lotri({
    eta.LClint ~ 0.0134021927622681
}), lotri({
    eta.LClint ~ 0.00816404639761548
}), lotri({
    eta.LClint ~ 0.0100442363659159
}), lotri({
    eta.LClint ~ 0.0133453124006483
}), lotri({
    eta.LClint ~ 0.0104331558194849
}), lotri({
    eta.LClint ~ 0.0177986449009373
}), lotri({
    eta.LClint ~ 0.0131212124528766
}), lotri({
    eta.LClint ~ 0.0139041542969029
}), lotri({
    eta.LClint ~ 0.0103794283245986
}), lotri({
    eta.LClint ~ 0.0146477950155837
}), lotri({
    eta.LClint ~ 0.015909949698264
}), lotri({
    eta.LClint ~ 0.0123842283807014
}), lotri({
    eta.LClint ~ 0.0142550264715035
}), lotri({
    eta.LClint ~ 0.0115968073284851
}), lotri({
    eta.LClint ~ 0.00871603307068386
}), lotri({
    eta.LClint ~ 0.0146984968701732
}), lotri({
    eta.LClint ~ 0.0115982920103258
}))
names(phiC) <- c("793", "794", "795", "796", "797", "798", "799", "800", "801", "802", "803", "804", "805", "806", "807", "808", "809", "810", "811")
