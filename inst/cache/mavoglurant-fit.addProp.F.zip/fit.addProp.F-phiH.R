phiH <- list(lotri({
    eta.LClint ~ 146.996990930571
}), lotri({
    eta.LClint ~ 95.4363058134609
}), lotri({
    eta.LClint ~ 95.7603879104981
}), lotri({
    eta.LClint ~ 132.892474096604
}), lotri({
    eta.LClint ~ 125.335905553583
}), lotri({
    eta.LClint ~ 95.6760541390292
}), lotri({
    eta.LClint ~ 119.471857190931
}), lotri({
    eta.LClint ~ 74.8674017973451
}), lotri({
    eta.LClint ~ 97.8737793690173
}), lotri({
    eta.LClint ~ 90.9934148609178
}), lotri({
    eta.LClint ~ 117.834377543067
}), lotri({
    eta.LClint ~ 88.8427903593882
}), lotri({
    eta.LClint ~ 84.5848846876208
}), lotri({
    eta.LClint ~ 116.88526185009
}), lotri({
    eta.LClint ~ 91.6631751665676
}), lotri({
    eta.LClint ~ 105.512072479906
}), lotri({
    eta.LClint ~ 126.454287954299
}), lotri({
    eta.LClint ~ 86.8928427005643
}), lotri({
    eta.LClint ~ 111.113633355764
}))
names(phiH) <- c("793", "794", "795", "796", "797", "798", "799", "800", "801", "802", "803", "804", "805", "806", "807", "808", "809", "810", "811")
