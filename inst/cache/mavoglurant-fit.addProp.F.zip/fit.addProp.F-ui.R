ui <- function () 
{
    ini({
        lKbBR <- 1.8010281278346
        lKbMU <- 0.497301271196148
        lKbAD <- 2.32969413039612
        lCLint <- 7.18118407404536
        lKbBO <- -0.356082853260022
        lKbRB <- 0.674325914255071
        add.err <- c(0, 0.447357015015062)
        prop.err <- c(0, 0.293716574552806)
        eta.LClint ~ 0.084987988233973
    })
    model({
        KbBR = exp(lKbBR)
        KbMU = exp(lKbMU)
        KbAD = exp(lKbAD)
        CLint = exp(lCLint + eta.LClint)
        KbBO = exp(lKbBO)
        KbRB = exp(lKbRB)
        CO = (187 * WT^0.81) * 60/1000
        QHT = 4 * CO/100
        QBR = 12 * CO/100
        QMU = 17 * CO/100
        QAD = 5 * CO/100
        QSK = 5 * CO/100
        QSP = 3 * CO/100
        QPA = 1 * CO/100
        QLI = 25.5 * CO/100
        QST = 1 * CO/100
        QGU = 14 * CO/100
        QHA = QLI - (QSP + QPA + QST + QGU)
        QBO = 5 * CO/100
        QKI = 19 * CO/100
        QRB = CO - (QHT + QBR + QMU + QAD + QSK + QLI + QBO + 
            QKI)
        QLU = QHT + QBR + QMU + QAD + QSK + QLI + QBO + QKI + 
            QRB
        VLU = (0.76 * WT/100)/1.051
        VHT = (0.47 * WT/100)/1.03
        VBR = (2 * WT/100)/1.036
        VMU = (40 * WT/100)/1.041
        VAD = (21.42 * WT/100)/0.916
        VSK = (3.71 * WT/100)/1.116
        VSP = (0.26 * WT/100)/1.054
        VPA = (0.14 * WT/100)/1.045
        VLI = (2.57 * WT/100)/1.04
        VST = (0.21 * WT/100)/1.05
        VGU = (1.44 * WT/100)/1.043
        VBO = (14.29 * WT/100)/1.99
        VKI = (0.44 * WT/100)/1.05
        VAB = (2.81 * WT/100)/1.04
        VVB = (5.62 * WT/100)/1.04
        VRB = (3.86 * WT/100)/1.04
        BP = 0.61
        fup = 0.028
        fub = fup/BP
        KbLU = exp(0.8334)
        KbHT = exp(1.1205)
        KbSK = exp(-0.5238)
        KbSP = exp(0.3224)
        KbPA = exp(0.3224)
        KbLI = exp(1.7604)
        KbST = exp(0.3224)
        KbGU = exp(1.2026)
        KbKI = exp(1.3171)
        S15 = VVB * BP/1000
        C15 = Venous_Blood/S15
        d/dt(Lungs) = QLU * (Venous_Blood/VVB - Lungs/KbLU/VLU)
        d/dt(Heart) = QHT * (Arterial_Blood/VAB - Heart/KbHT/VHT)
        d/dt(Brain) = QBR * (Arterial_Blood/VAB - Brain/KbBR/VBR)
        d/dt(Muscles) = QMU * (Arterial_Blood/VAB - Muscles/KbMU/VMU)
        d/dt(Adipose) = QAD * (Arterial_Blood/VAB - Adipose/KbAD/VAD)
        d/dt(Skin) = QSK * (Arterial_Blood/VAB - Skin/KbSK/VSK)
        d/dt(Spleen) = QSP * (Arterial_Blood/VAB - Spleen/KbSP/VSP)
        d/dt(Pancreas) = QPA * (Arterial_Blood/VAB - Pancreas/KbPA/VPA)
        d/dt(Liver) = QHA * Arterial_Blood/VAB + QSP * Spleen/KbSP/VSP + 
            QPA * Pancreas/KbPA/VPA + QST * Stomach/KbST/VST + 
            QGU * Gut/KbGU/VGU - CLint * fub * Liver/KbLI/VLI - 
            QLI * Liver/KbLI/VLI
        d/dt(Stomach) = QST * (Arterial_Blood/VAB - Stomach/KbST/VST)
        d/dt(Gut) = QGU * (Arterial_Blood/VAB - Gut/KbGU/VGU)
        d/dt(Bones) = QBO * (Arterial_Blood/VAB - Bones/KbBO/VBO)
        d/dt(Kidneys) = QKI * (Arterial_Blood/VAB - Kidneys/KbKI/VKI)
        d/dt(Arterial_Blood) = QLU * (Lungs/KbLU/VLU - Arterial_Blood/VAB)
        d/dt(Venous_Blood) = QHT * Heart/KbHT/VHT + QBR * Brain/KbBR/VBR + 
            QMU * Muscles/KbMU/VMU + QAD * Adipose/KbAD/VAD + 
            QSK * Skin/KbSK/VSK + QLI * Liver/KbLI/VLI + QBO * 
            Bones/KbBO/VBO + QKI * Kidneys/KbKI/VKI + QRB * Rest_of_Body/KbRB/VRB - 
            QLU * Venous_Blood/VVB
        d/dt(Rest_of_Body) = QRB * (Arterial_Blood/VAB - Rest_of_Body/KbRB/VRB)
        C15 ~ add(add.err) + prop(prop.err)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "pbpk", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

