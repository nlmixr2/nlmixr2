phiC <- list(lotri({
    eta.LClint ~ 0.0068028603420346
}), lotri({
    eta.LClint ~ 0.0104781926697225
}), lotri({
    eta.LClint ~ 0.0104427312986101
}), lotri({
    eta.LClint ~ 0.00752488059837809
}), lotri({
    eta.LClint ~ 0.0079785596600049
}), lotri({
    eta.LClint ~ 0.0104519360565066
}), lotri({
    eta.LClint ~ 0.00837017205149721
}), lotri({
    eta.LClint ~ 0.0133569480974757
}), lotri({
    eta.LClint ~ 0.0102172410879288
}), lotri({
    eta.LClint ~ 0.0109898062571724
}), lotri({
    eta.LClint ~ 0.00848648773686194
}), lotri({
    eta.LClint ~ 0.0112558373724506
}), lotri({
    eta.LClint ~ 0.011822443261501
}), lotri({
    eta.LClint ~ 0.00855539855215058
}), lotri({
    eta.LClint ~ 0.0109095064422854
}), lotri({
    eta.LClint ~ 0.00947758845501254
}), lotri({
    eta.LClint ~ 0.0079079959737024
}), lotri({
    eta.LClint ~ 0.0115084277245484
}), lotri({
    eta.LClint ~ 0.00899979570282068
}))
names(phiC) <- c("793", "794", "795", "796", "797", "798", "799", "800", "801", "802", "803", "804", "805", "806", "807", "808", "809", "810", "811")
