ui <- function () 
{
    ini({
        tka <- 0.463559040558007
        tcl <- 1.01056075022161
        tv <- 3.45495711054369
        add.sd <- c(0, 0.694821482461616)
        eta.ka ~ 0.396074889473505
        eta.cl ~ 0.0702760877394812
        eta.v ~ 0.0177158753249884
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

