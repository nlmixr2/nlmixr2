ui <- function () 
{
    ini({
        tka <- 0.169736872411108
        tcl1 <- -4.69399170199399
        tcl2 <- -4.46586050513134
        tv <- 3.38085691225036
        p1 <- 0.762287086087073
        add.sd <- c(0, 0.327505653905593)
        eta.cl ~ 1.72535999434776
        eta.v ~ 0.0339249430514182
    })
    model({
        ka <- exp(tka)
        cl <- mix(expit(tcl1 + eta.cl, 0.1, 200), p1, expit(tcl2 + 
            eta.cl, 0.1, 200))
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "twoPop", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

