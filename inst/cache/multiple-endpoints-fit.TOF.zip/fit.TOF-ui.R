ui <- function () 
{
    ini({
        tktr <- 0.0222346161788651
        tka <- 0.0222488930914909
        tcl <- -2.07404686646075
        tv <- 2.13351770109605
        prop.err <- c(0, 0.140620034050843)
        pkadd.err <- c(0, 0.124013508429599)
        temax <- 2.58396807167884
        tec50 <- -0.369667290403981
        tkout <- -2.91070065722643
        te0 <- 4.57815893412992
        pdadd.err <- c(0, 5.74260908450619)
        eta.ktr ~ 1.00531307185399
        eta.ka ~ 1.01742981474184
        eta.cl ~ 0.146012381629225
        eta.v ~ 0.163853951783032
        eta.emax ~ 0.491728901821343
        eta.ec50 ~ 0.824907290394824
        eta.kout ~ 0.190775497707073
        eta.e0 ~ 0.14273394788127
    })
    model({
        ktr <- exp(tktr + eta.ktr)
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        emax = expit(temax + eta.emax, 0, 1)
        ec50 = exp(tec50 + eta.ec50)
        kout = exp(tkout + eta.kout)
        e0 = exp(te0 + eta.e0)
        DCP = center/v
        PD = 1 - emax * DCP/(ec50 + DCP)
        effect(0) = e0
        kin = e0 * kout
        d/dt(depot) = -ktr * depot
        d/dt(gut) = ktr * depot - ka * gut
        d/dt(center) = ka * gut - cl/v * center
        d/dt(effect) = kin * PD - kout * effect
        cp = center/v
        cp ~ prop(prop.err) + add(pkadd.err)
        effect ~ add(pdadd.err) | pca
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "pk.turnover.emax3", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

