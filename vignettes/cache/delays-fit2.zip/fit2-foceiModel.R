foceiModel <- list()

foceiModel[["inner"]] <- NULL

foceiModel[["innerOeta"]] <- NULL

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3]);\ncmt(x1);\ncmt(x2);\ncmt(x4);\ncmt(x5);\nka=2495.04;\nke=2.5248;\nV=2.7882;\nl0=0.195;\nl1=0.245;\nw0=0.01;\nd/dt(x1)=-2495.04*x1;\nd/dt(x2)=2495.04*x1-2.5248*x2;\nrx_expr_0~x4+x5;\nrx_expr_1~exp(THETA[1]);\nrx_expr_4~0.358654328957751*rx_expr_1;\nrx_expr_5~rx_expr_4*x2;\nrx_expr_6~rx_expr_5*x4;\nd/dt(x4)=0.09555*Rx_pow_di(x4,2)/((rx_expr_0)*(0.245+0.39*x4))-rx_expr_6;\nrx_expr_2~exp(THETA[2]);\nd/dt(x5)=rx_expr_6-rx_expr_4*delay(x4,rx_expr_2)*delay(x2,rx_expr_2);\nx4(0)=0.01;\nx5(0)=0;\nrx_yj_~162;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=rx_expr_0;\nrx_r_=Rx_pow_di(THETA[3],2);\ntkpot=THETA[1];\nttau=THETA[2];\nadd.err=THETA[3];\nkpot=rx_expr_1;\ntau=rx_expr_2;\nc=0.358654328957751*x2;\ncdel=0.358654328957751*delay(x2,rx_expr_2);\nw=rx_expr_0;\ntad=tad();\ndosenum=dosenum();\ncmt(w);\ndvid(5);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- NULL

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L)

foceiModel[["eventEta"]] <- integer(0)

foceiModel[["predOnlyLlik"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3]);\ncmt(x1);\ncmt(x2);\ncmt(x4);\ncmt(x5);\nka=2495.04;\nke=2.5248;\nV=2.7882;\nl0=0.195;\nl1=0.245;\nw0=0.01;\nd/dt(x1)=-2495.04*x1;\nd/dt(x2)=2495.04*x1-2.5248*x2;\nrx_expr_0~x4+x5;\nrx_expr_1~exp(THETA[1]);\nrx_expr_4~0.358654328957751*rx_expr_1;\nrx_expr_5~rx_expr_4*x2;\nrx_expr_6~rx_expr_5*x4;\nd/dt(x4)=0.09555*Rx_pow_di(x4,2)/((rx_expr_0)*(0.245+0.39*x4))-rx_expr_6;\nrx_expr_2~exp(THETA[2]);\nd/dt(x5)=rx_expr_6-rx_expr_4*delay(x4,rx_expr_2)*delay(x2,rx_expr_2);\nx4(0)=0.01;\nx5(0)=0;\nrx_yj_~162;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=llikNorm(DV,rx_expr_0,sqrt(Rx_pow_di(THETA[3],2)));\nrx_r_=0;\ntkpot=THETA[1];\nttau=THETA[2];\nadd.err=THETA[3];\nkpot=rx_expr_1;\ntau=rx_expr_2;\nc=0.358654328957751*x2;\ncdel=0.358654328957751*delay(x2,rx_expr_2);\nw=rx_expr_0;\ntad=tad();\ndosenum=dosenum();\ncmt(w);\ndvid(5);\n")

class(foceiModel) <- "foceiModelList"

