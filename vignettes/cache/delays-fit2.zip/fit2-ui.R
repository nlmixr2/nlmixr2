ui <- function () 
{
    ini({
        tkpot <- c(-6.21460809842219, -4.98743101406919, -3.91202300542815)
        ttau <- c(0.405465108108164, 1.31245715476894, 1.79175946922805)
        add.err <- c(0.001, 0.18160818903118, 0.2)
    })
    model({
        ka <- 103.96 * 24
        ke <- 0.1052 * 24
        V <- 2.7882
        l0 <- 0.195
        l1 <- 0.245
        w0 <- 0.01
        kpot <- exp(tkpot)
        tau <- exp(ttau)
        d/dt(x1) <- -ka * x1
        d/dt(x2) <- ka * x1 - ke * x2
        c <- x2/V
        cdel <- delay(x2, tau)/V
        d/dt(x4) <- (2 * l0 * l1 * x4^2)/((l1 + 2 * l0 * x4) * 
            (x4 + x5)) - kpot * c * x4
        d/dt(x5) <- kpot * c * x4 - kpot * cdel * delay(x4, tau)
        x4(0) <- w0
        x5(0) <- 0
        w <- x4 + x5
        w ~ add(add.err)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "mod2", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

