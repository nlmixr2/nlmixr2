saemModel <- list()

saemModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],ETA[1],ETA[2],ETA[3]);\ncmt(depot);\ncmt(center);\nrx_pred_=NA;\nrx_r_=NA;\ntka=THETA[1]+ETA[1];\ntv=THETA[2]+ETA[2];\ntke=THETA[3]+ETA[3];\nadd.sd=THETA[4];\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~exp(tka);\nd/dt(depot)=-rx_expr_0*depot;\nd/dt(center)=rx_expr_0*depot-exp(tke)*center;\nrx_pred_=exp(-tv)*center;\nrx_r_=Rx_pow_di(add.sd,2);\nka=exp(tka);\nv=exp(tv);\nke=exp(tke);\ncp=exp(-tv)*center;\ntad=tad();\ndosenum=dosenum();\ntka=THETA[1];\ntv=THETA[2];\ntke=THETA[3];\nadd.sd=THETA[4];\neta.ka=ETA[1];\neta.v=ETA[2];\neta.ke=ETA[3];\ncmt(cp);\ndvid(3);\n")

class(saemModel) <- "saemModelList"

