ui <- function () 
{
    ini({
        tka <- 0.46711577918845
        tv <- 3.41087003428188
        tke <- -2.29698355556925
        add.sd <- c(0, 0.316802716088222)
        eta.ka ~ 0.637654243785524
        eta.v ~ 0.000285372847254924
        eta.ke ~ 0.00122766347011141
    })
    model({
        ka <- exp(tka + eta.ka)
        v <- exp(tv + eta.v)
        ke <- exp(tke + eta.ke)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - ke * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "oralModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

