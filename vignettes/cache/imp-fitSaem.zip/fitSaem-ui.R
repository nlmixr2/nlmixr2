ui <- function () 
{
    ini({
        tka <- 0.452253827365707
        tcl <- 1.01431877742518
        tv <- 3.45116253018048
        add.sd <- c(0, 0.69842755998907)
        eta.ka ~ 0.401467730044378
        eta.cl ~ 0.0733280754187312
        eta.v ~ 0.0176016229980007
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "impModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

