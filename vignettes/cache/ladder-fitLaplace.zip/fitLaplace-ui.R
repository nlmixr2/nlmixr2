ui <- function () 
{
    ini({
        tka <- 0.46481335982094
        tcl <- 1.01220767106091
        tv <- 3.45976392795262
        add.sd <- c(0, 0.694174369614001)
        eta.ka ~ 0.402192512236239
        eta.cl ~ 0.0692190869919827
        eta.v ~ 0.019269313998793
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

