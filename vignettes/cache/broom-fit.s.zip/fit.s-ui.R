ui <- function () 
{
    ini({
        tcl <- -5.00386939501454
        tv <- 0.346589111031303
        add.err <- c(0, 2.78116416789187)
        eta.cl ~ 0.237840266192592
        eta.v ~ c(0.187223853247402, 0.159294548705395)
    })
    model({
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        ke <- cl/v
        d/dt(A1) = -ke * A1
        cp = A1/v
        cp ~ add(add.err)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "pheno", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

