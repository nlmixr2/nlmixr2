saemModel <- list()

saemModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],ETA[1],ETA[2]);\ncmt(A1);\nrx_pred_=NA;\nrx_r_=NA;\ntcl=THETA[1]+ETA[1];\ntv=THETA[2]+ETA[2];\nadd.err=THETA[3];\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nd/dt(A1)=-exp(tcl-tv)*A1;\nrx_pred_=exp(-tv)*A1;\nrx_r_=Rx_pow_di(add.err,2);\ncl=exp(tcl);\nv=exp(tv);\nke=exp(tcl-tv);\ncp=exp(-tv)*A1;\ntad=tad();\ndosenum=dosenum();\ntcl=THETA[1];\ntv=THETA[2];\nadd.err=THETA[3];\neta.cl=ETA[1];\neta.v=ETA[2];\ncmt(cp);\ndvid(2);\n")

class(saemModel) <- "saemModelList"

