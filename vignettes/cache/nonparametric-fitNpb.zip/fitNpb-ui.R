ui <- function () 
{
    ini({
        tka <- 0.405465108108164
        tv <- 3.40119738166216
        tke <- -2.30258509299405
        add.sd <- c(0, 0.315778844307779)
        eta.ka ~ 0.643598359240818
        eta.v ~ 0.00299162425034181
        eta.ke ~ 0.00967994335320034
    })
    model({
        ka <- exp(tka + eta.ka)
        v <- exp(tv + eta.v)
        ke <- exp(tke + eta.ke)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - ke * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "oralModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

