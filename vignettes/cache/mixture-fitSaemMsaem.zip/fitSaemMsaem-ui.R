ui <- function () 
{
    ini({
        tka <- 0.124373893426775
        tcl1 <- -5.45110160123798
        tcl2 <- -3.37703295356096
        tv <- 3.36085968322245
        p1 <- 0.614910274107158
        add.sd <- c(0, 0.390883127889589)
        eta.cl ~ 0.974106935479439
        eta.v ~ 0.0315486802481094
    })
    model({
        ka <- exp(tka)
        cl <- mix(expit(tcl1 + eta.cl, 0.1, 200), p1, expit(tcl2 + 
            eta.cl, 0.1, 200))
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", ".funNew", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

