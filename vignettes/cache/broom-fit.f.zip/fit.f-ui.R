ui <- function () 
{
    ini({
        tcl <- -4.13150459395287
        tv <- -0.627848859661983
        add.err <- c(0, 0.330139209546518)
        eta.cl ~ 1.84215342845905
        eta.v ~ c(-1.05526559873479, 1.02708104294663)
    })
    model({
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        ke <- cl/v
        d/dt(A1) = -ke * A1
        cp = A1/v
        cp ~ add(add.err)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "pheno", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

