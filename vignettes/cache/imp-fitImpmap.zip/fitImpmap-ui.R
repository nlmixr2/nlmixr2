ui <- function () 
{
    ini({
        tka <- 0.461144029446391
        tcl <- 1.0067881252217
        tv <- 3.45378051754541
        add.sd <- c(0, 0.697420702557449)
        eta.ka ~ 0.405790160397523
        eta.cl ~ 0.0707609060902422
        eta.v ~ 0.0182471700807588
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "impModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

