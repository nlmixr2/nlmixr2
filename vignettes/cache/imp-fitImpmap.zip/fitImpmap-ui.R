ui <- function () 
{
    ini({
        tka <- 0.454047760200224
        tcl <- 1.01232124139148
        tv <- 3.45259068734307
        add.sd <- c(0, 0.695510309521648)
        eta.ka ~ 0.401109294686381
        eta.cl ~ 0.0710746447938011
        eta.v ~ 0.018717517137221
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "impModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

