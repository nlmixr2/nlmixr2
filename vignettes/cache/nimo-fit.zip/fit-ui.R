ui <- function () 
{
    ini({
        tcl <- -6.90453008037422
        tv1 <- 0.390938615631278
        tQ <- -5.61162027130274
        tv2 <- 3.57824247555066
        tkss <- 2.51974955563102
        tkint <- -0.925902220130505
        tksyn <- 0.00320027343860381
        tkdeg <- 2.14066278206322
        add.err <- c(0, 0.700196826611628)
        eta.cl ~ 0.0926345290811052
        eta.v1 ~ 0.282369177675627
        eta.kss ~ 0.996570303429917
    })
    model({
        cl <- exp(tcl + eta.cl)
        v1 <- exp(tv1 + eta.v1)
        Q <- exp(tQ)
        v2 <- exp(tv2)
        kss <- exp(tkss + eta.kss)
        kint <- exp(tkint)
        ksyn <- exp(tksyn)
        kdeg <- exp(tkdeg)
        k <- cl/v1
        k12 <- Q/v1
        k21 <- Q/v2
        eff(0) <- ksyn/kdeg
        conc = 0.5 * (central/v1 - eff - kss) + 0.5 * sqrt((central/v1 - 
            eff - kss)^2 + 4 * kss * central/v1)
        d/dt(central) = -(k + k12) * conc * v1 + k21 * peripheral - 
            kint * eff * conc * v1/(kss + conc)
        d/dt(peripheral) = k12 * conc * v1 - k21 * peripheral
        d/dt(eff) = ksyn - kdeg * eff - (kint - kdeg) * conc * 
            eff/(kss + conc)
        IPRED = log(conc)
        IPRED ~ add(add.err)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "nimo", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

