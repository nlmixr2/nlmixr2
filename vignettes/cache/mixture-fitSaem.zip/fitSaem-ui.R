ui <- function () 
{
    ini({
        tka <- 0.184978896704252
        tcl1 <- -4.0391103739359
        tcl2 <- -6.53734291237898
        tv <- 3.38322080871379
        p1 <- 0.866423710595445
        add.sd <- c(0, 0.326025238328319)
        eta.cl ~ 1.20795814468345
        eta.v ~ 0.0315678503619476
    })
    model({
        ka <- exp(tka)
        cl <- mix(expit(tcl1 + eta.cl, 0.1, 200), p1, expit(tcl2 + 
            eta.cl, 0.1, 200))
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "twoPop", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

