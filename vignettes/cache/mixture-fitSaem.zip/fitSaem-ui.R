ui <- function () 
{
    ini({
        tka <- 0.181747310345822
        tcl1 <- -5.51108238806496
        tcl2 <- -3.68319647100398
        tv <- 3.38205234468415
        p1 <- 0.637993670660984
        add.sd <- c(0, 0.326397498285949)
        eta.cl ~ 1.19269385831855
        eta.v ~ 0.0308414619360633
    })
    model({
        ka <- exp(tka)
        cl <- mix(expit(tcl1 + eta.cl, 0.1, 200), p1, expit(tcl2 + 
            eta.cl, 0.1, 200))
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "twoPop", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

