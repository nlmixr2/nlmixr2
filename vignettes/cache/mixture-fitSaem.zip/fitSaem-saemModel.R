saemModel <- list()

saemModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2]);\nrx_pred_=NA;\nrx_r_=NA;\ntka=THETA[1];\ntcl1=THETA[2];\ntcl2=THETA[3];\ntv=THETA[4]+ETA[2];\np1=THETA[5];\neta.cl=ETA[1];\nadd.sd=THETA[6];\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=linCmtA(rx__PTR__,t,2,1,1,-1,1,(0.1+199.9*(1/(1+exp(-(eta.cl+tcl2)))))*(mixest==2)+(mixest==1)*(0.1+199.9*(1/(1+exp(-(eta.cl+tcl1))))),exp(tv),0,0,0,0,exp(tka));\nrx_r_=Rx_pow_di(add.sd,2);\nka=exp(tka);\ncl=(0.1+199.9*(1/(1+exp(-(eta.cl+tcl2)))))*(mixest==2)+(mixest==1)*(0.1+199.9*(1/(1+exp(-(eta.cl+tcl1)))));\nv=exp(tv);\ntad=tad();\ndosenum=dosenum();\ntv=THETA[4];\neta.v=ETA[2];\ncmt(rxLinCmt);\ndvid(3);\n")

class(saemModel) <- "saemModelList"

