foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],ETA[1],ETA[2],ETA[3]);\ncmt(depot);\ncmt(center);\nrx_expr_3~ETA[1]+THETA[1];\nrx_expr_6~exp(rx_expr_3);\nd/dt(depot)=-rx_expr_6*depot;\nrx_expr_4~ETA[2]+THETA[2];\nrx_expr_5~ETA[3]+THETA[3];\nrx_expr_12~rx_expr_6*depot;\nrx_expr_15~rx_expr_4-(rx_expr_5);\nrx_expr_17~exp(rx_expr_15);\nrx_expr_19~rx_expr_17*center;\nd/dt(center)=rx_expr_12-rx_expr_19;\nrx_expr_21~rx_expr_6*rx__sens_depot_BY_ETA_1___;\nd/dt(rx__sens_depot_BY_ETA_1___)=-rx_expr_6*depot-rx_expr_21;\nd/dt(rx__sens_center_BY_ETA_1___)=rx_expr_12+rx_expr_21-rx_expr_17*rx__sens_center_BY_ETA_1___;\nd/dt(rx__sens_depot_BY_ETA_2___)=-rx_expr_6*rx__sens_depot_BY_ETA_2___;\nd/dt(rx__sens_center_BY_ETA_2___)=rx_expr_6*rx__sens_depot_BY_ETA_2___-rx_expr_19-rx_expr_17*rx__sens_center_BY_ETA_2___;\nd/dt(rx__sens_depot_BY_ETA_3___)=-rx_expr_6*rx__sens_depot_BY_ETA_3___;\nd/dt(rx__sens_center_BY_ETA_3___)=rx_expr_6*rx__sens_depot_BY_ETA_3___+rx_expr_19-rx_expr_17*rx__sens_center_BY_ETA_3___;\nrx_expr_0~CMT==4;\nrx_expr_1~CMT==3;\nrx_expr_2~1-(rx_expr_0);\nrx_yj_~2*(rx_expr_2)*(rx_expr_1)+2*(rx_expr_0);\nrx_expr_7~(rx_expr_2)*(rx_expr_1);\nrx_lambda_~rx_expr_7+(rx_expr_0);\nrx_hi_~rx_expr_7+(rx_expr_0);\nrx_low_~0;\nrx_expr_8~Rx_pow_di((rx_expr_0),2);\nrx_expr_9~Rx_pow_di((rx_expr_1),2);\nrx_expr_10~Rx_pow_di((rx_expr_1),3);\nrx_expr_11~exp(-(rx_expr_5));\nrx_expr_14~rx_expr_11*center;\nrx_expr_18~rx_expr_14*(rx_expr_2);\nrx_expr_20~rx_expr_11*rx_expr_8;\nrx_expr_24~rx_expr_18*rx_expr_9;\nrx_expr_25~rx_expr_18*rx_expr_10;\nrx_pred_=(rx_expr_0)*(rx_expr_20*center+rx_expr_24)+rx_expr_25;\nrx_expr_16~rx_expr_11*(rx_expr_2);\nrx_expr_22~rx_expr_16*rx_expr_9;\nrx_expr_23~rx_expr_16*rx_expr_10;\nrx__sens_rx_pred__BY_ETA_1___=rx__sens_center_BY_ETA_1___*((rx_expr_0)*(rx_expr_20+rx_expr_22)+rx_expr_23);\nrx__sens_rx_pred__BY_ETA_2___=rx__sens_center_BY_ETA_2___*((rx_expr_0)*(rx_expr_20+rx_expr_22)+rx_expr_23);\nrx__sens_rx_pred__BY_ETA_3___=rx__sens_center_BY_ETA_3___*((rx_expr_0)*(rx_expr_20+rx_expr_22)+rx_expr_23)+(rx_expr_0)*(-rx_expr_11*rx_expr_8*center-rx_expr_24)-rx_expr_25;\nrx_r_=(rx_expr_0)*Rx_pow_di(THETA[5],2)+(rx_expr_2)*Rx_pow_di(THETA[4],2)*(rx_expr_1);\nrx__sens_rx_r__BY_ETA_1___=0;\nrx__sens_rx_r__BY_ETA_2___=0;\nrx__sens_rx_r__BY_ETA_3___=0;\ncmt(phase1);\ncmt(phase3);\ndvid(3,4);\n")

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- "rx_expr_3~ETA[1]+THETA[1]\nrx_expr_6~exp(rx_expr_3)\nd/dt(depot)=-rx_expr_6*depot\nrx_expr_4~ETA[2]+THETA[2]\nrx_expr_5~ETA[3]+THETA[3]\nrx_expr_12~rx_expr_6*depot\nrx_expr_15~rx_expr_4-(rx_expr_5)\nrx_expr_17~exp(rx_expr_15)\nrx_expr_19~rx_expr_17*center\nd/dt(center)=rx_expr_12-rx_expr_19\nrx_expr_21~rx_expr_6*rx__sens_depot_BY_ETA_1___\nd/dt(rx__sens_depot_BY_ETA_1___)=-rx_expr_6*depot-rx_expr_21\nd/dt(rx__sens_center_BY_ETA_1___)=rx_expr_12+rx_expr_21-rx_expr_17*rx__sens_center_BY_ETA_1___\nd/dt(rx__sens_depot_BY_ETA_2___)=-rx_expr_6*rx__sens_depot_BY_ETA_2___\nd/dt(rx__sens_center_BY_ETA_2___)=rx_expr_6*rx__sens_depot_BY_ETA_2___-rx_expr_19-rx_expr_17*rx__sens_center_BY_ETA_2___\nd/dt(rx__sens_depot_BY_ETA_3___)=-rx_expr_6*rx__sens_depot_BY_ETA_3___\nd/dt(rx__sens_center_BY_ETA_3___)=rx_expr_6*rx__sens_depot_BY_ETA_3___+rx_expr_19-rx_expr_17*rx__sens_center_BY_ETA_3___\nrx_expr_0~CMT==4\nrx_expr_1~CMT==3\nrx_expr_2~1-(rx_expr_0)\nrx_yj_~2*(rx_expr_2)*(rx_expr_1)+2*(rx_expr_0)\nrx_expr_7~(rx_expr_2)*(rx_expr_1)\nrx_lambda_~rx_expr_7+(rx_expr_0)\nrx_hi_~rx_expr_7+(rx_expr_0)\nrx_low_~0\nrx_expr_8~Rx_pow_di((rx_expr_0), 2)\nrx_expr_9~Rx_pow_di((rx_expr_1), 2)\nrx_expr_10~Rx_pow_di((rx_expr_1), 3)\nrx_expr_11~exp(-(rx_expr_5))\nrx_expr_14~rx_expr_11*center\nrx_expr_18~rx_expr_14*(rx_expr_2)\nrx_expr_20~rx_expr_11*rx_expr_8\nrx_expr_24~rx_expr_18*rx_expr_9\nrx_expr_25~rx_expr_18*rx_expr_10\nrx_pred_=(rx_expr_0)*(rx_expr_20*center+rx_expr_24)+rx_expr_25\nrx_expr_16~rx_expr_11*(rx_expr_2)\nrx_expr_22~rx_expr_16*rx_expr_9\nrx_expr_23~rx_expr_16*rx_expr_10\nrx__sens_rx_pred__BY_ETA_1___=rx__sens_center_BY_ETA_1___*((rx_expr_0)*(rx_expr_20+rx_expr_22)+rx_expr_23)\nrx__sens_rx_pred__BY_ETA_2___=rx__sens_center_BY_ETA_2___*((rx_expr_0)*(rx_expr_20+rx_expr_22)+rx_expr_23)\nrx__sens_rx_pred__BY_ETA_3___=rx__sens_center_BY_ETA_3___*((rx_expr_0)*(rx_expr_20+rx_expr_22)+rx_expr_23)+(rx_expr_0)*(-rx_expr_11*rx_expr_8*center-rx_expr_24)-rx_expr_25\nrx_r_=(rx_expr_0)*Rx_pow_di(THETA[5], 2)+(rx_expr_2)*Rx_pow_di(THETA[4], 2)*(rx_expr_1)\nrx__sens_rx_r__BY_ETA_1___=0\nrx__sens_rx_r__BY_ETA_2___=0\nrx__sens_rx_r__BY_ETA_3___=0\nrx__ETA1=ETA[1]\nrx__ETA2=ETA[2]\nrx__ETA3=ETA[3]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],ETA[1],ETA[2],ETA[3]);\ncmt(depot);\ncmt(center);\nrx_expr_3~ETA[1]+THETA[1];\nrx_expr_6~exp(rx_expr_3);\nd/dt(depot)=-rx_expr_6*depot;\nrx_expr_4~ETA[2]+THETA[2];\nrx_expr_5~ETA[3]+THETA[3];\nd/dt(center)=rx_expr_6*depot-exp(rx_expr_4-(rx_expr_5))*center;\nrx_expr_0~CMT==4;\nrx_expr_1~CMT==3;\nrx_expr_2~1-(rx_expr_0);\nrx_yj_~2*(rx_expr_2)*(rx_expr_1)+2*(rx_expr_0);\nrx_expr_7~(rx_expr_2)*(rx_expr_1);\nrx_lambda_~rx_expr_7+(rx_expr_0);\nrx_hi_~rx_expr_7+(rx_expr_0);\nrx_low_~0;\nrx_expr_8~exp(-(rx_expr_5));\nrx_expr_10~rx_expr_8*center;\nrx_expr_11~rx_expr_10*(rx_expr_2);\nrx_pred_=(rx_expr_0)*(rx_expr_8*Rx_pow_di((rx_expr_0),2)*center+rx_expr_11*Rx_pow_di((rx_expr_1),2))+rx_expr_11*Rx_pow_di((rx_expr_1),3);\nrx_r_=(rx_expr_0)*Rx_pow_di(THETA[5],2)+(rx_expr_2)*Rx_pow_di(THETA[4],2)*(rx_expr_1);\ntka=THETA[1];\ntcl=THETA[2];\ntv=THETA[3];\nphase1.sd=THETA[4];\nphase3.sd=THETA[5];\neta.ka=ETA[1];\neta.cl=ETA[2];\neta.v=ETA[3];\nka=rx_expr_6;\ncl=exp(rx_expr_4);\nv=exp(rx_expr_5);\ncp=rx_expr_10;\ntad=tad();\ndosenum=dosenum();\ncmt(phase1);\ncmt(phase3);\ndvid(3,4);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],ETA[1],ETA[2],ETA[3],CMT);\ncmt(depot);\ncmt(center);\nrx_expr_3~ETA[1]+THETA[1];\nrx_expr_5~exp(rx_expr_3);\nd/dt(depot)=-rx_expr_5*depot;\nrx_expr_4~ETA[3]+THETA[3];\nd/dt(center)=rx_expr_5*depot-exp(ETA[2]+THETA[2]-(rx_expr_4))*center;\nrx_expr_0~CMT==4;\nrx_expr_1~CMT==3;\nrx_expr_2~1-(rx_expr_0);\nrx_yj_~2*(rx_expr_2)*(rx_expr_1)+2*(rx_expr_0);\nrx_expr_6~(rx_expr_2)*(rx_expr_1);\nrx_lambda_~rx_expr_6+(rx_expr_0);\nrx_hi_~rx_expr_6+(rx_expr_0);\nrx_low_~0;\nrx_expr_7~exp(-(rx_expr_4));\nrx_expr_9~rx_expr_7*center;\nrx_expr_10~rx_expr_9*(rx_expr_2);\nrx_pred_=(rx_expr_0)*(rx_expr_7*Rx_pow_di((rx_expr_0),2)*center+rx_expr_10*Rx_pow_di((rx_expr_1),2))+rx_expr_10*Rx_pow_di((rx_expr_1),3);\nrx_r_=(rx_expr_0)*Rx_pow_di(THETA[5],2)+(rx_expr_2)*Rx_pow_di(THETA[4],2)*(rx_expr_1);\ncmt(phase1);\ncmt(phase3);\ndvid(3,4);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- c(0L, 0L, 0L)

class(foceiModel) <- "foceiModelList"

