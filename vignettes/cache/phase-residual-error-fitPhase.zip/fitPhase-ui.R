ui <- function () 
{
    ini({
        tka <- 0.316598757321489
        label("Log Ka")
        tcl <- 0.951612224585141
        label("Log Cl")
        tv <- 3.51256302656901
        label("Log V")
        phase1.sd <- c(0, 0.168522030397428)
        label("Phase 1 additive error (mg/L)")
        phase3.sd <- c(0, 0.840682886312489)
        label("Phase 3 additive error (mg/L)")
        eta.ka ~ 0.362305515984515
        eta.cl ~ 0.312591957494942
        eta.v ~ 0.106540634510488
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(phase1.sd) | phase1
        cp ~ add(phase3.sd) | phase3
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "pkPhase", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

