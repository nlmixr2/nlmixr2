ui <- function () 
{
    ini({
        tka <- 0.440287123339013
        tcl <- 0.961492099825321
        tv <- 3.49228675479103
        add.sd <- c(0, 1.37541201444146)
    })
    model({
        ka <- exp(tka)
        cl <- exp(tcl)
        v <- exp(tv)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "popModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

