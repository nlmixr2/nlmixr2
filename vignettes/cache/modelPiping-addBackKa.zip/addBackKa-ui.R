ui <- function () 
{
    ini({
        tka <- 0.461622681077803
        label("Ka")
        tcl <- 1.01303541384788
        label("Cl")
        tv <- 3.45945662780387
        label("V")
        add.sd <- c(0, 0.693685287429444)
        eta.cl ~ 0.0688735777410789
        eta.v ~ 0.0192032733816209
        bsv.ka ~ 0.405900548505178
    })
    model({
        ka <- exp(tka + bsv.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) = -ka * depot
        d/dt(center) = ka * depot - cl/v * center
        cp = center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", c("$", "rxui", "fun"), envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

