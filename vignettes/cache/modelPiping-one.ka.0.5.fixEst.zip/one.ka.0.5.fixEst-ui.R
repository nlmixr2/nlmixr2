ui <- function () 
{
    ini({
        tka <- fix(0.466256075749994)
        label("Ka")
        tcl <- 1.01219586924335
        label("Cl")
        tv <- 3.46003000832391
        label("V")
        add.sd <- c(0, 0.694675212983217)
        eta.ka ~ 0.399027019127495
        eta.cl ~ 0.0693524612128899
        eta.v ~ 0.0190760887636208
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) = -ka * depot
        d/dt(center) = ka * depot - cl/v * center
        cp = center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "one.compartment", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

