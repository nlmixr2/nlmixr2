ui <- function () 
{
    ini({
        tka <- 0.405465108108164
        tv <- 3.40119738166216
        tke <- -2.30258509299405
        add.sd <- c(0, 0.30298109537165)
        eta.ka ~ 0.665416570100434
        eta.v ~ 0.00260594685022467
        eta.ke ~ 0.00776698838582377
    })
    model({
        ka <- exp(tka + eta.ka)
        v <- exp(tv + eta.v)
        ke <- exp(tke + eta.ke)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - ke * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "oralModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

