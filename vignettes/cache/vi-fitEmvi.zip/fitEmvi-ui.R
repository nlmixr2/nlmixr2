ui <- function () 
{
    ini({
        tka <- 0.391942446541559
        tcl <- 1.02562048094909
        tv <- 3.42642753291306
        add.sd <- c(0, 0.79752581718141)
        eta.ka ~ 0.332545003865946
        eta.cl ~ 0.134842056457518
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

