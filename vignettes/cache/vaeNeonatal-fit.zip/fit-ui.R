ui <- function () 
{
    ini({
        lW0 <- 8.18293049236
        lkin <- 4.49865811174
        lTL <- 0.512124484649
        lkoutmax <- -2.6548526291
        lT50 <- 0.020230580783
        add.err <- c(0, 17.971475719)
        prop.err <- c(0, 0.00992620767505)
        beta_lW0_SEX <- 0.0899327583903
        beta_lW0_GA <- 1.85802166929
        beta_lkin_GA <- 1.880300043
        eta.W0 ~ 0.0159450547442
        eta.kin ~ 0.03674796268
        eta.TL ~ 0.0170515718949
        eta.koutmax ~ 0.00994443131307001
        eta.T50 ~ 0.0238772779187
    })
    model({
        W0 <- exp(lW0 + beta_lW0_SEX * (SEX - 0.481481481481) + 
            beta_lW0_GA * log(GA/39.7114451852) + eta.W0)
        kin <- exp(lkin + beta_lkin_GA * log(GA/39.7114451852) + 
            eta.kin)
        TL <- exp(lTL + eta.TL)
        koutmax <- exp(lkoutmax + eta.koutmax)
        T50 <- exp(lT50 + eta.T50)
        kprod <- kin * expit(2 * (t - TL), 0, 1)
        kelim <- koutmax * (1 - t/(T50 + t))
        d/dt(W) <- kprod - kelim * W
        W(0) <- W0
        W ~ add(add.err) + prop(prop.err)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "x", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

