foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],THETA[7],THETA[8],THETA[9],THETA[10],ETA[1],ETA[2],ETA[3],ETA[4],ETA[5],SEX,GA);\ncmt(W);\nrx_expr_0~ETA[2]+THETA[2];\nrx_expr_1~ETA[3]+THETA[3];\nrx_expr_2~ETA[4]+THETA[4];\nrx_expr_3~ETA[5]+THETA[5];\nrx_expr_5~exp(rx_expr_1);\nrx_expr_6~exp(rx_expr_2);\nrx_expr_7~exp(rx_expr_3);\nrx_expr_8~0.0251816572108206*GA;\nrx_expr_9~t-rx_expr_5;\nrx_expr_10~t+rx_expr_7;\nrx_expr_11~log(rx_expr_8);\nrx_expr_12~t/(rx_expr_10);\nrx_expr_13~1-rx_expr_12;\nrx_expr_15~exp(-2*(rx_expr_9));\nrx_expr_16~1+rx_expr_15;\nrx_expr_18~THETA[10]*rx_expr_11;\nrx_expr_21~rx_expr_0+rx_expr_18;\nrx_expr_22~exp(rx_expr_21);\nrx_expr_23~rx_expr_22;\nrx_expr_26~rx_expr_23/(rx_expr_16);\nd/dt(W)=rx_expr_26-W*rx_expr_6*(rx_expr_13);\nrx_expr_4~ETA[1]+THETA[1];\nrx_expr_14~(-0.481481481481+SEX)*THETA[8];\nrx_expr_17~rx_expr_11*THETA[9];\nrx_expr_19~rx_expr_4+rx_expr_14;\nrx_expr_24~rx_expr_19+rx_expr_17;\nrx_expr_25~exp(rx_expr_24);\nW(0)=rx_expr_25;\nd/dt(rx__sens_W_BY_ETA_1___)=-rx_expr_6*(rx_expr_13)*rx__sens_W_BY_ETA_1___;\nrx__sens_W_BY_ETA_1___(0)=rx_expr_25;\nrx_expr_20~rx_expr_6*(rx_expr_13);\nd/dt(rx__sens_W_BY_ETA_2___)=rx_expr_26-rx_expr_20*rx__sens_W_BY_ETA_2___;\nd/dt(rx__sens_W_BY_ETA_3___)=-2*exp(ETA[2]+ETA[3]+THETA[2]+THETA[3]+rx_expr_18-2*(rx_expr_9))/Rx_pow_di((rx_expr_16),2)-rx_expr_20*rx__sens_W_BY_ETA_3___;\nd/dt(rx__sens_W_BY_ETA_4___)=-W*rx_expr_6*(rx_expr_13)-rx_expr_20*rx__sens_W_BY_ETA_4___;\nd/dt(rx__sens_W_BY_ETA_5___)=-rx_expr_6*(rx_expr_13)*rx__sens_W_BY_ETA_5___-W*t*exp(ETA[4]+ETA[5]+THETA[4]+THETA[5])/Rx_pow_di((rx_expr_10),2);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=W;\nrx__sens_rx_pred__BY_ETA_1___=rx__sens_W_BY_ETA_1___;\nrx__sens_rx_pred__BY_ETA_2___=rx__sens_W_BY_ETA_2___;\nrx__sens_rx_pred__BY_ETA_3___=rx__sens_W_BY_ETA_3___;\nrx__sens_rx_pred__BY_ETA_4___=rx__sens_W_BY_ETA_4___;\nrx__sens_rx_pred__BY_ETA_5___=rx__sens_W_BY_ETA_5___;\nrx_r_=Rx_pow_di(W,2)*Rx_pow_di(THETA[7],2)+Rx_pow_di(THETA[6],2);\ndvid(1);\n")

foceiModel[["innerOeta"]] <- "rx_expr_0~ETA[2]+THETA[2]\nrx_expr_1~ETA[3]+THETA[3]\nrx_expr_2~ETA[4]+THETA[4]\nrx_expr_3~ETA[5]+THETA[5]\nrx_expr_5~exp(rx_expr_1)\nrx_expr_6~exp(rx_expr_2)\nrx_expr_7~exp(rx_expr_3)\nrx_expr_8~0.0251816572108206*GA\nrx_expr_9~t-rx_expr_5\nrx_expr_10~t+rx_expr_7\nrx_expr_11~log(rx_expr_8)\nrx_expr_12~t/(rx_expr_10)\nrx_expr_13~1-rx_expr_12\nrx_expr_15~exp(-2*(rx_expr_9))\nrx_expr_16~1+rx_expr_15\nrx_expr_18~THETA[10]*rx_expr_11\nrx_expr_21~rx_expr_0+rx_expr_18\nrx_expr_22~exp(rx_expr_21)\nrx_expr_23~rx_expr_22\nrx_expr_26~rx_expr_23/(rx_expr_16)\nd/dt(W)=rx_expr_26-W*rx_expr_6*(rx_expr_13)\nrx_expr_4~ETA[1]+THETA[1]\nrx_expr_14~(-0.481481481481+SEX)*THETA[8]\nrx_expr_17~rx_expr_11*THETA[9]\nrx_expr_19~rx_expr_4+rx_expr_14\nrx_expr_24~rx_expr_19+rx_expr_17\nrx_expr_25~exp(rx_expr_24)\nW(0)=rx_expr_25\nd/dt(rx__sens_W_BY_ETA_1___)=-rx_expr_6*(rx_expr_13)*rx__sens_W_BY_ETA_1___\nrx__sens_W_BY_ETA_1___(0)=rx_expr_25\nrx_expr_20~rx_expr_6*(rx_expr_13)\nd/dt(rx__sens_W_BY_ETA_2___)=rx_expr_26-rx_expr_20*rx__sens_W_BY_ETA_2___\nd/dt(rx__sens_W_BY_ETA_3___)=-2*exp(ETA[2]+ETA[3]+THETA[2]+THETA[3]+rx_expr_18-2*(rx_expr_9))/Rx_pow_di((rx_expr_16), 2)-rx_expr_20*rx__sens_W_BY_ETA_3___\nd/dt(rx__sens_W_BY_ETA_4___)=-W*rx_expr_6*(rx_expr_13)-rx_expr_20*rx__sens_W_BY_ETA_4___\nd/dt(rx__sens_W_BY_ETA_5___)=-rx_expr_6*(rx_expr_13)*rx__sens_W_BY_ETA_5___-W*t*exp(ETA[4]+ETA[5]+THETA[4]+THETA[5])/Rx_pow_di((rx_expr_10), 2)\nrx_yj_~2\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_pred_=W\nrx__sens_rx_pred__BY_ETA_1___=rx__sens_W_BY_ETA_1___\nrx__sens_rx_pred__BY_ETA_2___=rx__sens_W_BY_ETA_2___\nrx__sens_rx_pred__BY_ETA_3___=rx__sens_W_BY_ETA_3___\nrx__sens_rx_pred__BY_ETA_4___=rx__sens_W_BY_ETA_4___\nrx__sens_rx_pred__BY_ETA_5___=rx__sens_W_BY_ETA_5___\nrx_r_=Rx_pow_di(W, 2)*Rx_pow_di(THETA[7], 2)+Rx_pow_di(THETA[6], 2)\nrx__ETA1=ETA[1]\nrx__ETA2=ETA[2]\nrx__ETA3=ETA[3]\nrx__ETA4=ETA[4]\nrx__ETA5=ETA[5]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],THETA[7],THETA[8],THETA[9],THETA[10],ETA[1],ETA[2],ETA[3],ETA[4],ETA[5],SEX,GA);\ncmt(W);\nrx_expr_0~ETA[2]+THETA[2];\nrx_expr_1~ETA[3]+THETA[3];\nrx_expr_2~ETA[4]+THETA[4];\nrx_expr_3~ETA[5]+THETA[5];\nrx_expr_5~exp(rx_expr_1);\nrx_expr_6~exp(rx_expr_2);\nrx_expr_7~exp(rx_expr_3);\nrx_expr_8~0.0251816572108206*GA;\nrx_expr_9~t-rx_expr_5;\nrx_expr_10~t+rx_expr_7;\nrx_expr_11~log(rx_expr_8);\nrx_expr_12~t/(rx_expr_10);\nrx_expr_13~1-rx_expr_12;\nrx_expr_15~exp(-2*(rx_expr_9));\nrx_expr_16~1+rx_expr_15;\nrx_expr_18~THETA[10]*rx_expr_11;\nrx_expr_20~rx_expr_0+rx_expr_18;\nrx_expr_21~exp(rx_expr_20);\nrx_expr_22~rx_expr_21;\nrx_expr_25~rx_expr_22/(rx_expr_16);\nd/dt(W)=rx_expr_25-W*rx_expr_6*(rx_expr_13);\nrx_expr_4~ETA[1]+THETA[1];\nrx_expr_14~(-0.481481481481+SEX)*THETA[8];\nrx_expr_17~rx_expr_11*THETA[9];\nrx_expr_19~rx_expr_4+rx_expr_14;\nrx_expr_23~rx_expr_19+rx_expr_17;\nrx_expr_24~exp(rx_expr_23);\nW(0)=rx_expr_24;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=W;\nrx_r_=Rx_pow_di(W,2)*Rx_pow_di(THETA[7],2)+Rx_pow_di(THETA[6],2);\nlW0=THETA[1];\nlkin=THETA[2];\nlTL=THETA[3];\nlkoutmax=THETA[4];\nlT50=THETA[5];\nadd.err=THETA[6];\nprop.err=THETA[7];\nbeta_lW0_SEX=THETA[8];\nbeta_lW0_GA=THETA[9];\nbeta_lkin_GA=THETA[10];\neta.W0=ETA[1];\neta.kin=ETA[2];\neta.TL=ETA[3];\neta.koutmax=ETA[4];\neta.T50=ETA[5];\nW0=rx_expr_24;\nkin=rx_expr_21;\nTL=rx_expr_5;\nkoutmax=rx_expr_6;\nT50=rx_expr_7;\nkprod=rx_expr_25;\nkelim=rx_expr_6*(rx_expr_13);\ntad=tad();\ndosenum=dosenum();\ndvid(1);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],THETA[7],THETA[8],THETA[9],THETA[10],ETA[1],ETA[2],ETA[3],ETA[4],ETA[5],SEX,GA);\ncmt(W);\nparam(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],THETA[7],THETA[8],THETA[9],THETA[10],ETA[1],ETA[2],ETA[3],ETA[4],ETA[5],SEX,GA);\nrx_expr_0~0.0251816572108206*GA;\nrx_expr_1~log(rx_expr_0);\nd/dt(W)=exp(ETA[2]+THETA[2]+THETA[10]*rx_expr_1)/(1+exp(-2*(t-exp(ETA[3]+THETA[3]))))-W*exp(ETA[4]+THETA[4])*(1-t/(t+exp(ETA[5]+THETA[5])));\nW(0)=exp(ETA[1]+THETA[1]+(-0.481481481481+SEX)*THETA[8]+rx_expr_1*THETA[9]);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=W;\nrx_r_=Rx_pow_di(W,2)*Rx_pow_di(THETA[7],2)+Rx_pow_di(THETA[6],2);\ndvid(1);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- c(0L, 0L, 0L, 0L, 0L)

class(foceiModel) <- "foceiModelList"

