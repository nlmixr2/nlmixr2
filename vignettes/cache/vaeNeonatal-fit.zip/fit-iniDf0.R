iniDf0 <- function () 
{
    ini({
        lW0 <- 8.00636756765025
        lkin <- 3.40119738166216
        lTL <- 0.693147180559945
        lkoutmax <- -2.99573227355399
        lT50 <- 0
        add.err <- c(0, 30)
        prop.err <- c(0, 0.02)
        eta.W0 ~ 0.001
        eta.kin ~ 0.01
        eta.TL ~ 0.05
        eta.koutmax ~ 0.05
        eta.T50 ~ 0.05
    })
    model({
        W0 <- exp(lW0 + eta.W0)
        kin <- exp(lkin + eta.kin)
        TL <- exp(lTL + eta.TL)
        koutmax <- exp(lkoutmax + eta.koutmax)
        T50 <- exp(lT50 + eta.T50)
        kprod <- kin * expit(2 * (t - TL), 0, 1)
        kelim <- koutmax * (1 - t/(T50 + t))
        d/dt(W) <- kprod - kelim * W
        W(0) <- W0
        W ~ add(add.err) + prop(prop.err)
    })
}
iniDf0 <- rxode2::rxode2(iniDf0)
iniDf0 <- rxode2::rxUiDecompress(iniDf0)
assign("modelName", "neonatalModel", envir=, iniDf0)
rm("model", envir=iniDf0)
iniDf0 <- rxode2::rxUiCompress(iniDf0)

