ui <- function () 
{
    ini({
        tka <- 0.166106878839251
        tcl1 <- -4.68546304416928
        tcl2 <- -4.48941167204946
        tv <- 3.37775682408901
        p1 <- 0.775462747745461
        add.sd <- c(0, 0.327564026538141)
        eta.cl ~ 1.72537906134686
        eta.v ~ 0.0328595956822102
    })
    model({
        ka <- exp(tka)
        cl <- mix(expit(tcl1 + eta.cl, 0.1, 200), p1, expit(tcl2 + 
            eta.cl, 0.1, 200))
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "twoPop", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

