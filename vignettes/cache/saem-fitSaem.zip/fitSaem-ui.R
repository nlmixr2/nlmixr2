ui <- function () 
{
    ini({
        tka <- 0.463874285465822
        tcl <- 1.00899017877842
        tv <- 3.45566299698261
        add.sd <- c(0, 0.69734751199422)
        eta.ka ~ 0.402732477821704
        eta.cl ~ 0.0712110407674699
        eta.v ~ 0.0187572598423505
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

