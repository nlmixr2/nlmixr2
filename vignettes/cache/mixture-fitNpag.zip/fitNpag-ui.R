ui <- function () 
{
    ini({
        tka <- 0.19217606655582
        tcl1 <- -4.28578076018094
        tcl2 <- -4.88131283185658
        tv <- 3.40027728116443
        p1 <- 0.60430503027233
        add.sd <- c(0, 0.316034449037315)
        eta.cl ~ 1.17826227499213
        eta.v ~ 0.0392576855777753
    })
    model({
        ka <- exp(tka)
        cl <- mix(expit(tcl1 + eta.cl, 0.1, 200), p1, expit(tcl2 + 
            eta.cl, 0.1, 200))
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "twoPop", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

