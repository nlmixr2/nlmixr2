ui <- function () 
{
    ini({
        tka <- 0.464490113431984
        label("Ka")
        tcl <- 1.01264363359736
        label("Cl")
        tv <- 3.45995693026234
        label("V")
        add.sd <- c(0, 0.694797259559384)
        eta.ka ~ 0.396536799300741
        eta.cl ~ 0.0690816971997341
        eta.v ~ 0.0191636163819864
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) = -ka * depot
        d/dt(center) = ka * depot - cl/v * center
        cp = center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "x", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

