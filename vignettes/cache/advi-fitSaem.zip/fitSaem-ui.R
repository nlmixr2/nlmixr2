ui <- function () 
{
    ini({
        tka <- 0.392484421488139
        tcl <- 1.03280958886146
        tv <- 3.42386088976783
        add.sd <- c(0, 0.779601919966841)
        eta.ka ~ 0.33248738061507
        eta.cl ~ 0.120890313032958
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

