`fitOptim` <- function() {
source('fitOptim-env.R', local=TRUE)
.class <- env$`..class..`
.id.level <- env$`..id.level..`
rm('..class..', envir=env)
rm('..id.level..', envir=env)
source('fitOptim-foceiModel.R', local=TRUE)
env$`foceiModel` <- foceiModel

env$`iniDf0` <- read.csv('fitOptim-iniDf0.csv',check.names=FALSE, row.names=1)
env$iniDf0$ntheta <- as.integer(env$iniDf0$ntheta)
env$iniDf0$neta1 <- as.double(env$iniDf0$neta1)
env$iniDf0$neta2 <- as.double(env$iniDf0$neta2)
env$iniDf0$name <- as.character(env$iniDf0$name)
env$iniDf0$lower <- as.double(env$iniDf0$lower)
env$iniDf0$upper <- as.double(env$iniDf0$upper)
env$iniDf0$est <- as.double(env$iniDf0$est)
env$iniDf0$fix <- as.logical(env$iniDf0$fix)
env$iniDf0$label <- as.character(env$iniDf0$label)
env$iniDf0$backTransform <- as.character(env$iniDf0$backTransform)
env$iniDf0$condition <- as.character(env$iniDf0$condition)
env$iniDf0$err <- as.character(env$iniDf0$err)

env$objDf <- read.csv('fitOptim-objDf.csv',check.names=FALSE, row.names=1)
env$objDf$OBJF <- as.double(env$objDf$OBJF)
env$objDf$AIC <- as.double(env$objDf$AIC)
env$objDf$BIC <- as.double(env$objDf$BIC)
env$objDf$`Log-likelihood` <- as.double(env$objDf$`Log-likelihood`)

env$`origData` <- read.csv('fitOptim-origData.csv', check.names=FALSE)

env$`parFixed` <- read.csv('fitOptim-parFixed.csv',check.names=FALSE, row.names=1, colClasses="character")
class(env$`parFixed`) <- c('nlmixr2ParFixed', 'data.frame')

env$`parFixedDf` <- read.csv('fitOptim-parFixedDf.csv',check.names=FALSE, row.names=1)
env$`parFixedDf` <- nlmixr2save::nlmixr2saveParFixedDf(env$`parFixedDf`, named=TRUE)

env$`parHistData` <- read.csv('fitOptim-parHistData.csv', check.names=FALSE)

env$`scaleInfo` <- readRDS('fitOptim-scaleInfo.rds')

env$`sessioninfo` <- readRDS('fitOptim-sessioninfo.rds')

env$`time` <- read.csv('fitOptim-time.csv',check.names=FALSE, row.names=1)

source('fitOptim-ui.R', local=TRUE)
env$`ui` <- ui
env$model <- rxode2::model(env$ui)
if (!is.null(.id.level)) {
  if (!is.null(env$ranef$ID)) {
    env$ranef$ID <- factor(env$ranef$ID, levels=.id.level)
  }
  if (!is.null(env$etaObf$ID)) {
    env$etaObf$ID <- factor(env$etaObf$ID, levels=.id.level)
  }
}
if (!is.null(env$parHistData)) {
  env$parHistData$type <- factor(env$parHistData$type, levels=c("Gill83 Gradient", "Mixed Gradient", "Forward Difference", "Central Difference", "Scaled", "Unscaled", "Back-Transformed", "Forward Sensitivity"))
  env$parHistData$iter <- as.integer(env$parHistData$iter)
}
if (exists('saemControl', env) && is.numeric(env$saemControl$mcmc$niter[1])) {
    .parHistData <- env$parHistData
    .cls <- class(.parHistData)
    attr(.cls, 'niter') <- env$saemControl$mcmc$niter[1]
    class(.parHistData) <- .cls
    env$parHistData <- .parHistData
}
if (any(.class == 'nlmixr2FitData')) {
  ret <- read.csv('fitOptim.csv')
  class(env) <- 'nlmixr2FitCoreSilent'
  attr(.class, '.foceiEnv') <- env
  class(ret) <- .class
  return(ret)
} else {
  ret <- env
  class(ret) <- .class
  return(ret)
}
}
`fitOptim` <- `fitOptim`()

