ui <- function () 
{
    ini({
        tka <- 0.447804269953302
        tcl <- 1.02454792790437
        tv <- 3.44759317122623
        add.sd <- c(0, 0.679760020390432)
        eta.ka ~ 0.301682581381531
        eta.cl ~ c(0.00374201012040696, 0.00413297868491429)
        eta.v ~ c(0.00340111682951203, 0.000977049608255377, 
            0.000268435573301108)
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

