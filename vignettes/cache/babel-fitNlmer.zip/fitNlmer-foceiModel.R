foceiModel <- list()

foceiModel[["inner"]] <- NULL

foceiModel[["innerOeta"]] <- NULL

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],ETA[1],ETA[2],ETA[3]);\ncmt(depot);\ncmt(center);\nrx_expr_0~ETA[1]+THETA[1];\nrx_expr_3~exp(rx_expr_0);\nd/dt(depot)=-rx_expr_3*depot;\nrx_expr_1~ETA[2]+THETA[2];\nrx_expr_2~ETA[3]+THETA[3];\nd/dt(center)=rx_expr_3*depot-exp(rx_expr_1-(rx_expr_2))*center;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_4~exp(-(rx_expr_2));\nrx_expr_5~rx_expr_4*center;\nrx_pred_=rx_expr_5;\nrx_r_=Rx_pow_di(THETA[4],2);\ntka=THETA[1];\ntcl=THETA[2];\ntv=THETA[3];\nadd.sd=THETA[4];\neta.ka=ETA[1];\neta.cl=ETA[2];\neta.v=ETA[3];\nka=rx_expr_3;\ncl=exp(rx_expr_1);\nv=exp(rx_expr_2);\ncp=rx_expr_5;\ntad=tad();\ndosenum=dosenum();\ncmt(cp);\ndvid(3);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- NULL

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- c(0L, 0L, 0L)

class(foceiModel) <- "foceiModelList"

