ui <- function () 
{
    ini({
        tka <- 0.401806044301197
        tcl <- 1.02755619315712
        tv <- 3.42953435341175
        add.sd <- c(0, 0.781886557204063)
        eta.ka ~ 0.329261175482419
        eta.cl ~ 0.120937197467424
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

