ui <- function () 
{
    ini({
        tka <- 0.458494934961364
        tcl <- 1.01202562836581
        tv <- 3.45400665779186
        add.sd <- c(0, 0.696113060326752)
        eta.ka ~ 0.401763983502907
        eta.cl ~ 0.0700053319898366
        eta.v ~ 0.0184505789914783
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "impModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

