ui <- function () 
{
    ini({
        tka <- 0.394620284328385
        tcl <- 1.03493695662184
        tv <- 3.43955113597182
        add.sd <- c(0, 0.798239147573086)
        eta.ka ~ 0.331308645855543
        eta.cl ~ 0.133258129862054
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

