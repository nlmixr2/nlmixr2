ui <- function () 
{
    ini({
        tka <- 0.458672171497577
        tcl <- 1.01163805633017
        tv <- 3.45406576665787
        add.sd <- c(0, 0.696051971950841)
        eta.ka ~ 0.40343154762769
        eta.cl ~ 0.0702836660049294
        eta.v ~ 0.0184297611361326
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "theoModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

