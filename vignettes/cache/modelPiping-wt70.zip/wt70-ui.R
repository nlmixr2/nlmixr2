ui <- function () 
{
    ini({
        tka <- fix(0.5)
        label("Ka")
        tcl <- 1.02143292853841
        label("Cl")
        tv <- 3.46169976252375
        label("V")
        add.sd <- c(0, 0.696352877150985)
        covWtPow <- fix(0.75)
        eta.ka ~ 0.393186776614569
        eta.cl ~ 0.0662021674200008
        eta.v ~ 0.0188779232433465
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl) * (WT/70)^covWtPow
        v <- exp(tv + eta.v)
        d/dt(depot) = -ka * depot
        d/dt(center) = ka * depot - cl/v * center
        cp = center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", c("$", "rxui", "fun"), envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

