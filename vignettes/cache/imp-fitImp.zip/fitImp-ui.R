ui <- function () 
{
    ini({
        tka <- 0.459544166139812
        tcl <- 1.01295384526449
        tv <- 3.4524244564293
        add.sd <- c(0, 0.694786100416065)
        eta.ka ~ 0.408470627052358
        eta.cl ~ 0.0705258128710829
        eta.v ~ 0.0183100636916699
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "impModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

