foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],ETA[1],ETA[2]);\ncmt(depot);\ncmt(center);\nrx_expr_0~exp(THETA[1]);\nd/dt(depot)=-rx_expr_0*depot;\nrx_expr_1~ETA[1]+THETA[2];\nrx_expr_2~ETA[2]+THETA[3];\nrx_expr_4~rx_expr_1-(rx_expr_2);\nrx_expr_5~exp(rx_expr_4);\nrx_expr_6~rx_expr_5*center;\nd/dt(center)=rx_expr_0*depot-rx_expr_6;\nd/dt(rx__sens_depot_BY_ETA_1___)=-rx_expr_0*rx__sens_depot_BY_ETA_1___;\nd/dt(rx__sens_center_BY_ETA_1___)=rx_expr_0*rx__sens_depot_BY_ETA_1___-rx_expr_6-rx_expr_5*rx__sens_center_BY_ETA_1___;\nd/dt(rx__sens_depot_BY_ETA_2___)=-rx_expr_0*rx__sens_depot_BY_ETA_2___;\nd/dt(rx__sens_center_BY_ETA_2___)=rx_expr_0*rx__sens_depot_BY_ETA_2___+rx_expr_6-rx_expr_5*rx__sens_center_BY_ETA_2___;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_3~exp(-(rx_expr_2));\nrx_pred_=rx_expr_3*center;\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_3*rx__sens_center_BY_ETA_1___;\nrx__sens_rx_pred__BY_ETA_2___=-rx_expr_3*center+rx_expr_3*rx__sens_center_BY_ETA_2___;\nrx_r_=Rx_pow_di(THETA[4],2);\nrx__sens_rx_r__BY_ETA_1___=0;\nrx__sens_rx_r__BY_ETA_2___=0;\ncmt(cp);\ndvid(3);\n")

foceiModel[["innerOeta"]] <- "rx_expr_0~exp(THETA[1])\nd/dt(depot)=-rx_expr_0*depot\nrx_expr_1~ETA[1]+THETA[2]\nrx_expr_2~ETA[2]+THETA[3]\nrx_expr_4~rx_expr_1-(rx_expr_2)\nrx_expr_5~exp(rx_expr_4)\nrx_expr_6~rx_expr_5*center\nd/dt(center)=rx_expr_0*depot-rx_expr_6\nd/dt(rx__sens_depot_BY_ETA_1___)=-rx_expr_0*rx__sens_depot_BY_ETA_1___\nd/dt(rx__sens_center_BY_ETA_1___)=rx_expr_0*rx__sens_depot_BY_ETA_1___-rx_expr_6-rx_expr_5*rx__sens_center_BY_ETA_1___\nd/dt(rx__sens_depot_BY_ETA_2___)=-rx_expr_0*rx__sens_depot_BY_ETA_2___\nd/dt(rx__sens_center_BY_ETA_2___)=rx_expr_0*rx__sens_depot_BY_ETA_2___+rx_expr_6-rx_expr_5*rx__sens_center_BY_ETA_2___\nrx_yj_~2\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_expr_3~exp(-(rx_expr_2))\nrx_pred_=rx_expr_3*center\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_3*rx__sens_center_BY_ETA_1___\nrx__sens_rx_pred__BY_ETA_2___=-rx_expr_3*center+rx_expr_3*rx__sens_center_BY_ETA_2___\nrx_r_=Rx_pow_di(THETA[4], 2)\nrx__sens_rx_r__BY_ETA_1___=0\nrx__sens_rx_r__BY_ETA_2___=0\nrx__ETA1=ETA[1]\nrx__ETA2=ETA[2]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],ETA[1],ETA[2]);\ncmt(depot);\ncmt(center);\nrx_expr_0~exp(THETA[1]);\nd/dt(depot)=-rx_expr_0*depot;\nrx_expr_1~ETA[1]+THETA[2];\nrx_expr_2~ETA[2]+THETA[3];\nd/dt(center)=rx_expr_0*depot-exp(rx_expr_1-(rx_expr_2))*center;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_3~exp(-(rx_expr_2));\nrx_expr_4~rx_expr_3*center;\nrx_pred_=rx_expr_4;\nrx_r_=Rx_pow_di(THETA[4],2);\ntka=THETA[1];\ntcl=THETA[2];\ntv=THETA[3];\nadd.sd=THETA[4];\neta.cl=ETA[1];\neta.v=ETA[2];\nka=rx_expr_0;\ncl=exp(rx_expr_1);\nv=exp(rx_expr_2);\ncp=rx_expr_4;\ntad=tad();\ndosenum=dosenum();\ncmt(cp);\ndvid(3);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],ETA[1],ETA[2]);\ncmt(depot);\ncmt(center);\nparam(THETA[1],THETA[2],THETA[3],THETA[4],ETA[1],ETA[2]);\nrx_expr_0~exp(THETA[1]);\nd/dt(depot)=-rx_expr_0*depot;\nrx_expr_1~ETA[2]+THETA[3];\nd/dt(center)=rx_expr_0*depot-exp(ETA[1]+THETA[2]-(rx_expr_1))*center;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=exp(-(rx_expr_1))*center;\nrx_r_=Rx_pow_di(THETA[4],2);\ncmt(cp);\ndvid(3);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- c(0L, 0L)

class(foceiModel) <- "foceiModelList"

