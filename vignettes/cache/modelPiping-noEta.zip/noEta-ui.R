ui <- function () 
{
    ini({
        tka <- 0.432960201611463
        label("Ka")
        tcl <- 0.99034307892067
        label("Cl")
        tv <- 3.47969597524636
        label("V")
        add.sd <- c(0, 1.02033118481151)
        eta.cl ~ 0.0882700983239666
        eta.v ~ 0.0232560423938922
    })
    model({
        ka <- exp(tka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) = -ka * depot
        d/dt(center) = ka * depot - cl/v * center
        cp = center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", c("$", "rxui", "fun"), envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

